package com.am.spring_jsf.bean;

import java.math.BigDecimal;

public class FullCategoryDetail{

	private BigDecimal categoryDetailId;
	private String position;
	private BigDecimal quantity;
	private BigDecimal buyingPrice;
	private BigDecimal originalSellingPrice;
	private String dNote;
	private String condition;
	private String dDeleteFlg;
	private String dLImgPath;
	private String dSImgPath;
	private BigDecimal currentSellingPrice;
	private BigDecimal discountPercent;
	private BigDecimal partId;
	private BigDecimal brandId;
	private BigDecimal categoryId;
	private Long year;
	private String make;
	private String model;
	private String brandName;
	private String partName;
	
	public FullCategoryDetail() {}
	
	public FullCategoryDetail(BigDecimal categoryDetailId,String position,BigDecimal quantity,BigDecimal buyingPrice,BigDecimal originalSellingPrice,String dNote,String condition,String dDeleteFlg,String dLImgPath,String dSImgPath,BigDecimal currentSellingPrice,BigDecimal discountPercent,BigDecimal partId,BigDecimal brandId,BigDecimal categoryId,Long year,String make,String model,String brandName,String partName) {
		 this.categoryDetailId=categoryDetailId;
		 this.position=position;
		 this.quantity=quantity;
		 this.buyingPrice=buyingPrice;
		 this.originalSellingPrice=originalSellingPrice;
		 this.dNote=dNote;
		 this.condition=condition;
		 this.dDeleteFlg=dDeleteFlg;
		 this.dLImgPath=dLImgPath;
		 this.dSImgPath=dSImgPath;
		 this.currentSellingPrice=currentSellingPrice;
		 this.discountPercent=discountPercent;
		 this.partId=partId;
		 this.brandId=brandId;
		 this.categoryId=categoryId;
		 this.year=year;
		 this.make=make;
		 this.model=model;
		 this.brandName=brandName;
		 this.partName=partName;
	}
	
	public Long getYear() {
		return year;
	}
	public void setYear(Long year) {
		this.year = year;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public BigDecimal getCategoryDetailId() {
		return categoryDetailId;
	}
	public void setCategoryDetailId(BigDecimal categoryDetailId) {
		this.categoryDetailId = categoryDetailId;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public BigDecimal getQuantity() {
		return quantity;
	}
	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}
	public BigDecimal getBuyingPrice() {
		return buyingPrice;
	}
	public void setBuyingPrice(BigDecimal buyingPrice) {
		this.buyingPrice = buyingPrice;
	}
	public BigDecimal getOriginalSellingPrice() {
		return originalSellingPrice;
	}
	public void setOriginalSellingPrice(BigDecimal originalSellingPrice) {
		this.originalSellingPrice = originalSellingPrice;
	}
	public String getdNote() {
		return dNote;
	}
	public void setdNote(String dNote) {
		this.dNote = dNote;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getdDeleteFlg() {
		return dDeleteFlg;
	}
	public void setdDeleteFlg(String dDeleteFlg) {
		this.dDeleteFlg = dDeleteFlg;
	}
	public String getdLImgPath() {
		return dLImgPath;
	}
	public void setdLImgPath(String dLImgPath) {
		this.dLImgPath = dLImgPath;
	}
	public String getdSImgPath() {
		return dSImgPath;
	}
	public void setdSImgPath(String dSImgPath) {
		this.dSImgPath = dSImgPath;
	}
	public BigDecimal getCurrentSellingPrice() {
		return currentSellingPrice;
	}
	public void setCurrentSellingPrice(BigDecimal currentSellingPrice) {
		this.currentSellingPrice = currentSellingPrice;
	}
	public BigDecimal getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(BigDecimal discountPercent) {
		this.discountPercent = discountPercent;
	}
	public BigDecimal getPartId() {
		return partId;
	}
	public void setPartId(BigDecimal partId) {
		this.partId = partId;
	}
	public BigDecimal getBrandId() {
		return brandId;
	}
	public void setBrandId(BigDecimal brandId) {
		this.brandId = brandId;
	}
	public BigDecimal getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(BigDecimal categoryId) {
		this.categoryId = categoryId;
	}
	
	
	

}
