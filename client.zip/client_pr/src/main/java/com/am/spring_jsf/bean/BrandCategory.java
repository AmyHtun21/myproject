package com.am.spring_jsf.bean;

import java.math.BigDecimal;

public class BrandCategory {

	private BigDecimal brandId;
	private String brandName;
	private String partName;
	private String imgPath;
	private String note;
	
	public BrandCategory(BigDecimal brandId,String brandName,String partName,String imgPath,String note) {
		
		this.brandId=brandId;
		this.brandName=brandName;
		this.partName=partName;
		this.imgPath=imgPath;
		this.note=note;
	}
	
	
    public boolean equals(BrandCategory brandCategory) {
        return (this.brandName.equals(brandCategory.brandName) && this.partName.equals(brandCategory.partName));
    }
    
    public  int hashCode() {
    	
    	return brandId.intValue();
    }



	public BigDecimal getBrandId() {
		return brandId;
	}


	public void setBrandId(BigDecimal brandId) {
		this.brandId = brandId;
	}


	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}
	
    
    
}
