package com.am.spring_jsf.bean;

import java.math.BigDecimal;

public class Customer {
	
	private BigDecimal customerId;
	private String customerName;
	private String customerPhone;
	private String customerEmail;
	private String customerAddress;
	private String blockFlg;
	public BigDecimal getCustomerId() {
		return customerId;
	}
	public void setCustomerId(BigDecimal customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getBlockFlg() {
		return blockFlg;
	}
	public void setBlockFlg(String blockFlg) {
		this.blockFlg = blockFlg;
	}
	
	

}
