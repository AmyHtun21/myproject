package com.am.spring_jsf.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.am.spring_jsf.bean.CategoryItem;
import com.am.spring_jsf.bean.Customer;
import com.am.spring_jsf.bean.ErrorMessage;
import com.am.spring_jsf.bean.FullCategoryDetail;
import com.am.spring_jsf.bean.OrderDetailInfo;
import com.am.spring_jsf.bean.OrderInfo;
import com.am.spring_jsf.bean.OrderLists;
import com.am.spring_jsf.bean.SellOrder;

@Scope(value="request")
@Component("trackOrderController")
@ELBeanName("trackOrderController")
@Join(path="/trackOrders",to="track-order.jsf")
public class TrackOrderController extends CommonController{
	
	
	private final String ORDER_SEARCH="http://localhost:8082/searchNewOrders";
	
	
	private SellOrder sellOrder;
	
	private Customer customer;
	
	private List<OrderInfo> orderInfoList;
	
	private String customerName=null;
	private Long customerPhone=null;
	private String customerEmail=null;
	private String customerAddress=null;
	private Long   sellOrderId=null;
	private String errorMessage=null;
	private boolean errFlg;
	private RestTemplate restTemplate = new RestTemplate();
	
	
	
	public String trackOrderOnLoad() {
		this.customerName=null;
		this.customerPhone=null;
		this.customerEmail=null;
		this.customerAddress=null;
		this.sellOrderId=null;
		System.out.println("Reach in  onLoad"+this.errFlg);
		if(labelDetailBean==null) {
			return "/Language.xhtml?faces-redirect=true";
		}
		 return "/track-order.xhtml";
	}
	
	public String searchOrders() {
		System.out.println("Reach in search method");
		if(this.customerName==null&&this.customerPhone==null&&this.customerEmail==null&&this.sellOrderId==null) {
			this.errorMessage=errorDetailBean.getNoData();
			this.errFlg=true;
			System.out.println("Reach in boolean test"+this.errFlg);
			return "/track-order.xhtml";
		}
		System.out.println("Customer data"+this.customerName+"phone"+this.customerPhone+"email"+this.customerEmail+"sel"+this.sellOrderId);
		StringBuffer callUrl=new StringBuffer(ORDER_SEARCH);

		if(this.customerName!=null) {
			callUrl.append("?customerName="+customerName);
		}
		else if(this.customerPhone!=null) {
			callUrl.append("?customerPhone="+customerPhone);
		}
		else if(this.customerEmail!=null) {
			callUrl.append("?customerEmail="+customerEmail);
		}
		else if(this.sellOrderId!=null) {
			callUrl.append("?sellOrderId="+sellOrderId);
		}
System.out.println("Track Url is "+callUrl+customerPhone+"is is custdata");
		ResponseEntity<OrderInfo[]> responseEntity=restTemplate.getForEntity(callUrl.toString(), OrderInfo[].class);
		this.orderInfoList=Arrays.asList(responseEntity.getBody());
		this.errFlg=false;
		return "/track-order-detail.xhtml";

	}
	
	
	public SellOrder getSellOrder() {
		return sellOrder;
	}

	public void setSellOrder(SellOrder sellOrder) {
		this.sellOrder = sellOrder;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Long getCustomerPhone() {
		return customerPhone;
	}

	public void setCustomerPhone(Long customerPhone) {
		this.customerPhone = customerPhone;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}


	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public String getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public List<OrderInfo> getOrderInfoList() {
		return orderInfoList;
	}

	public void setOrderInfoList(List<OrderInfo> orderInfoList) {
		this.orderInfoList = orderInfoList;
	}

	public Long getSellOrderId() {
		return sellOrderId;
	}

	public void setSellOrderId(Long sellOrderId) {
		this.sellOrderId = sellOrderId;
	}

	public boolean isErrFlg() {
		return errFlg;
	}

	public void setErrFlg(boolean errFlg) {
		this.errFlg = errFlg;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}




	
	

}
