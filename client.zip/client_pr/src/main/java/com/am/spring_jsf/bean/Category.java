package com.am.spring_jsf.bean;

import java.util.Set;


public class Category {
	
	private Long categoryId;
	private Long year;
	private String make;
	private String model;
	private String cDeleteFlg;
	

	public Long getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}
	public Long getYear() {
		return year;
	}
	public void setYear(Long year) {
		this.year = year;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getcDeleteFlg() {
		return cDeleteFlg;
	}
	public void setcDeleteFlg(String cDeleteFlg) {
		this.cDeleteFlg = cDeleteFlg;
	}

	public String toString() {
		return year+make+model;
	}

}
