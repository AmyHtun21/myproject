package com.am.spring_jsf.bean;


public class Brand {
	private Long brandId;
	private String brandName;
	private String brandImagePath;
	private String brandNote;
	
	public Long getBrandId() {
		return brandId;
	}
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getBrandImagePath() {
		return brandImagePath;
	}
	public void setBrandImagePath(String brandImagePath) {
		this.brandImagePath = brandImagePath;
	}
	public String getBrandNote() {
		return brandNote;
	}
	public void setBrandNote(String brandNote) {
		this.brandNote = brandNote;
	}
	
	

}
