package com.am.spring_jsf.bean;

import java.math.BigDecimal;

public class DeliveryInfo {
	
	private String deliveryId;
	private BigDecimal deliveryFees;
	public String getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
	public BigDecimal getDeliveryFees() {
		return deliveryFees;
	}
	public void setDeliveryFees(BigDecimal deliveryFees) {
		this.deliveryFees = deliveryFees;
	}
	

}
