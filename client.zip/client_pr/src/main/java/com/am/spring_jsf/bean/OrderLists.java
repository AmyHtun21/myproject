package com.am.spring_jsf.bean;

import java.math.BigDecimal;
import java.util.List;

public class OrderLists {
	
	private List<OrderDetailInfo> orderList;
	
	private Customer customer;
	
	private String deliveryId;
	
	private BigDecimal deliveryFees;
	
	private BigDecimal allNetAmount;

	public List<OrderDetailInfo> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<OrderDetailInfo> orderList) {
		this.orderList = orderList;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public BigDecimal getDeliveryFees() {
		return deliveryFees;
	}

	public void setDeliveryFees(BigDecimal deliveryFees) {
		this.deliveryFees = deliveryFees;
	}

	public BigDecimal getAllNetAmount() {
		return allNetAmount;
	}

	public void setAllNetAmount(BigDecimal allNetAmount) {
		this.allNetAmount = allNetAmount;
	}


	

}
