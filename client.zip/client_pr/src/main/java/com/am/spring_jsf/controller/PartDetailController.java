package com.am.spring_jsf.controller;

public class PartDetailController extends CommonController{

	public PartDetailController() {
		// TODO Auto-generated constructor stub
	}

}
