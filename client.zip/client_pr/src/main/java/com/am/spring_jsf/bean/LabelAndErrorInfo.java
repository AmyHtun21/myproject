package com.am.spring_jsf.bean;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class LabelAndErrorInfo {
	
	final static String INITIAL="http://localhost:8082/initialList";
	public static List<ErrorMessage> errorList;
	public static List<LabelBean> labelList;
	
	public static void intialLoad() {
		RestTemplate template=new RestTemplate();
		ResponseEntity<InitialBean> resposeEntity=template.getForEntity(INITIAL, InitialBean.class);
		InitialBean initialBean=resposeEntity.getBody();
		labelList=initialBean.getLabelList();
		errorList=initialBean.getErrorList();
	}

}
