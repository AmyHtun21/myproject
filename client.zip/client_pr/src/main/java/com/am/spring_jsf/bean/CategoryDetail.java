package com.am.spring_jsf.bean;


public class CategoryDetail {
	
	private Long categoryDetailId;
	private String catDeName;
	private String position;
	private Long quantity;
	private Long buyingPrice;
	private Long sellingPrice;
	private String note;
	private String condition;
	private String deleteFlg;
	private String lImgPath;
	private String sImgPath;
	private Long brandId;
    
	private Category category;


	public Long getCategoryDetailId() {
		return categoryDetailId;
	}
	public void setCategoryDetailId(Long categoryDetailId) {
		this.categoryDetailId = categoryDetailId;
	}
	public String getCatDeName() {
		return catDeName;
	}
	public void setCatDeName(String catDeName) {
		this.catDeName = catDeName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public Long getQuantity() {
		return quantity;
	}
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	public Long getBuyingPrice() {
		return buyingPrice;
	}
	public void setBuyingPrice(Long buyingPrice) {
		this.buyingPrice = buyingPrice;
	}
	public Long getSellingPrice() {
		return sellingPrice;
	}
	public void setSellingPrice(Long sellingPrice) {
		this.sellingPrice = sellingPrice;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getDeleteFlg() {
		return deleteFlg;
	}
	public void setDeleteFlg(String deleteFlg) {
		this.deleteFlg = deleteFlg;
	}
	public String getlImgPath() {
		return lImgPath;
	}
	public void setlImgPath(String lImgPath) {
		this.lImgPath = lImgPath;
	}
	public String getsImgPath() {
		return sImgPath;
	}
	public void setsImgPath(String sImgPath) {
		this.sImgPath = sImgPath;
	}
/*	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}*/
	public Long getBrandId() {
		return brandId;
	}
	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}
	
	

}
