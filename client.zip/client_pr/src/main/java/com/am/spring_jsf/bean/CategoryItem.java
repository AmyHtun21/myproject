package com.am.spring_jsf.bean;

import java.util.List;
import java.util.Map;

public class CategoryItem {

	private List<Category> categoryList;
	private Map<Long,Long> year;
	private Map<Long,Map<String,String>> makeMap;
	private Map<String,Map<String,String>> modelMap;
	private Map<String,String> makeData;
	private Map<String,String> modelData;
	public Map<Long, Long> getYear() {
		return year;
	}
	public void setYear(Map<Long, Long> year) {
		this.year = year;
	}
	public Map<Long, Map<String, String>> getMakeMap() {
		return makeMap;
	}
	public void setMakeMap(Map<Long, Map<String, String>> makeMap) {
		this.makeMap = makeMap;
	}
	public Map<String, Map<String, String>> getModelMap() {
		return modelMap;
	}
	public void setModelMap(Map<String, Map<String, String>> modelMap) {
		this.modelMap = modelMap;
	}
	public Map<String, String> getMakeData() {
		return makeData;
	}
	public void setMakeData(Map<String, String> makeData) {
		this.makeData = makeData;
	}
	public Map<String, String> getModelData() {
		return modelData;
	}
	public void setModelData(Map<String, String> modelData) {
		this.modelData = modelData;
	}
	public List<Category> getCategoryList() {
		return categoryList;
	}
	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}
	
	

	
	
}
