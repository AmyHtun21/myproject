package com.am.spring_jsf;

import org.ocpsoft.rewrite.servlet.RewriteFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.servlet.FilterRegistrationBean;

import org.springframework.boot.web.servlet.ServletRegistrationBean;

import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.event.EventListener;
import org.springframework.web.client.RestTemplate;

import com.am.spring_jsf.bean.LabelAndErrorInfo;
import com.am.spring_jsf.controller.CommonController;
import com.am.spring_jsf.controller.HomeController;

import javax.faces.webapp.FacesServlet;

import javax.servlet.DispatcherType;

import java.util.EnumSet;
import java.util.List;

@EnableAutoConfiguration

@ComponentScan({"com.am.spring_jsf"})

public class App extends SpringBootServletInitializer {
	
    public static void main(String[] args) {
    	ConfigurableApplicationContext context = SpringApplication.run(App.class, args);
    	//context.getBean(LabelAndErrorInfo.class).intialLoad();

    }
    
    @EventListener(ApplicationReadyEvent.class)
    public void doSomethingAfterStartup() {
    	LabelAndErrorInfo.intialLoad();
        System.out.println("hello world, I have just started up");
    }

    @Bean

    public ServletRegistrationBean servletRegistrationBean() {

        FacesServlet servlet = new FacesServlet();

        return new ServletRegistrationBean(servlet, "*.jsf");

    }

    @Bean

    public FilterRegistrationBean rewriteFilter() {

        FilterRegistrationBean rwFilter = new FilterRegistrationBean(new RewriteFilter());

        rwFilter.setDispatcherTypes(EnumSet.of(DispatcherType.FORWARD, DispatcherType.REQUEST,

                DispatcherType.ASYNC, DispatcherType.ERROR));

        rwFilter.addUrlPatterns("/*");

        return rwFilter;

    }

}