package com.am.spring_jsf.controller;


import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;

import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.am.spring_jsf.bean.ErrorDetailBean;
import com.am.spring_jsf.bean.ErrorMessage;
import com.am.spring_jsf.bean.InitialBean;
import com.am.spring_jsf.bean.LabelAndErrorInfo;
import com.am.spring_jsf.bean.LabelBean;
import com.am.spring_jsf.bean.LabelDetailBean;

@Scope(value = "session")

@Component(value = "commonController")

@ELBeanName(value = "commonController")
public class CommonController {
	
	final String LABEL="http://localhost:8082/labelList";
	
	
	
	static List<LabelBean> labelBean;
	
	static List<ErrorMessage> errorMessageList;
	
	static LabelDetailBean labelDetailBean;
	
	static ErrorDetailBean errorDetailBean;
	
	private String language;
	
	private String errorMessage;
	
	public static boolean commSearchRender=true;
	
	private boolean errorMessageFlg;
	

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}




	public  List<LabelBean> getLabelBean() {
		return labelBean;
	}

	public  void setLabelBean(List<LabelBean> labelBean) {
		CommonController.labelBean = labelBean;
	}

	public static boolean isCommSearchRender() {
		return commSearchRender;
	}

	public static void setCommSearchRender(boolean commSearchRender) {
		CommonController.commSearchRender = commSearchRender;
	}

	public boolean isErrorMessageFlg() {
		return errorMessageFlg;
	}

	public void setErrorMessageFlg(boolean errorMessageFlg) {
		this.errorMessageFlg = errorMessageFlg;
	}
	
	public void changeLanguage(String language) {

	}

	public  LabelDetailBean getLabelDetailBean() {
		return labelDetailBean;
	}

	public  void setLabelDetailBean(LabelDetailBean labelDetailBean) {
		labelDetailBean = labelDetailBean;
	}
	
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	

	public   List<ErrorMessage> getErrorMessageList() {
		return errorMessageList;
	}

	public   void setErrorMessageList(List<ErrorMessage> errorMessageList) {
		CommonController.errorMessageList = errorMessageList;
	}
	

	public  ErrorDetailBean getErrorDetailBean() {
		return errorDetailBean;
	}

	public  void setErrorDetailBean(ErrorDetailBean errorDetailBean) {
		CommonController.errorDetailBean = errorDetailBean;
	}

	public void changeLanguage (ActionEvent event){
		 
		language = (String)event.getComponent().getAttributes().get("language");
	 
	  }
	
	
	public String setLableValue() {
		LabelDetailBean labelDetail=new LabelDetailBean();
		ErrorDetailBean errorDetail=new ErrorDetailBean();
		System.out.println("Reach in setLabelValue"+language);
			for(LabelBean label:LabelAndErrorInfo.labelList) {
			
				if(label.getLanguage().equals(language)) {
					System.out.println(label.getLabelName()+language+label.getValue());
					if(label.getLabelName().equals("home")) {
						labelDetail.setHome(label.getValue());
					}
					if(label.getLabelName().equals("catalog")) {
						labelDetail.setCatalog(label.getValue());
					}
					if(label.getLabelName().equals("brand")) {
						labelDetail.setBrand(label.getValue());
					}
					if(label.getLabelName().equals("customerService")) {
						labelDetail.setCustomerService(label.getValue());
					}
					if(label.getLabelName().equals("track")) {
						labelDetail.setTrack(label.getValue());
					}
					if(label.getLabelName().equals("view")) {
						labelDetail.setView(label.getValue());
					}
					if(label.getLabelName().equals("checkOut")) {
						labelDetail.setCheckOut(label.getValue());
					}
					if(label.getLabelName().equals("submit")) {
						labelDetail.setSubmit(label.getValue());
					}
					if(label.getLabelName().equals("cancel")) {
						labelDetail.setCancel(label.getValue());
					}
					if(label.getLabelName().equals("year")) {
						labelDetail.setYear(label.getValue());
					}
					if(label.getLabelName().equals("model")) {
					labelDetail.setModel(label.getValue());	
					}
					if(label.getLabelName().equals("make")) {
						labelDetail.setMake(label.getValue());
					}
					if(label.getLabelName().equals("part")) {
						System.out.println("Enter in part"+label.getValue());
						labelDetail.setPart(label.getValue());
					}
					if(label.getLabelName().equals("position")) {
						labelDetail.setPosition(label.getValue());
					}
					if(label.getLabelName().equals("condition")) {
						labelDetail.setCondition(label.getValue());
					}
					if(label.getLabelName().equals("currentPrice")) {
					labelDetail.setCurrentPrice(label.getValue());	
					}
					if(label.getLabelName().equals("originalPrice")) {
						labelDetail.setOriginalPrice(label.getValue());
					}
					if(label.getLabelName().equals("serviceTax")) {
						labelDetail.setServiceTax(label.getValue());
					}
					if(label.getLabelName().equals("commercialTax")) {
						labelDetail.setCommercialTax(label.getValue());
					}
					if(label.getLabelName().equals("deliveryFee")) {
						labelDetail.setDeliveryFee(label.getValue());
					}
					if(label.getLabelName().equals("totalCharge")) {
						labelDetail.setTotalCharge(label.getValue());
					}
					if(label.getLabelName().equals("address")) {
						labelDetail.setAddress(label.getValue());
					}
					if(label.getLabelName().equals("phoneNo")) {
						labelDetail.setPhoneNo(label.getValue());
					}
					if(label.getLabelName().equals("email")) {
						labelDetail.setEmail(label.getValue());
					}
					if(label.getLabelName().equals("brands")) {
						labelDetail.setBrands(label.getValue());
					}
					if(label.getLabelName().equals("bestSellerParts")) {
						labelDetail.setBestSellerParts(label.getValue());
					}
					if(label.getLabelName().equals("bestSellerBrands")) {
						labelDetail.setBestSellerBrands(label.getValue());
					}
					if(label.getLabelName().equals("shopMoreParts")) {
						labelDetail.setShopMoreParts(label.getValue());
					}
					if(label.getLabelName().equals("shopByMake")) {
						labelDetail.setShopByMake(label.getValue());
					}
					if(label.getLabelName().equals("search")) {
						labelDetail.setSearch(label.getValue());
					}
					if(label.getLabelName().equals("trackOrderHeader")) {
						labelDetail.setTrackOrderHeader(label.getValue());
					}
					if(label.getLabelName().equals("category")) {
						labelDetail.setCategory(label.getValue());
					}
					if(label.getLabelName().equals("price")) {
						labelDetail.setPrice(label.getValue());
					}
					if(label.getLabelName().equals("quantity")) {
						labelDetail.setQuantity(label.getValue());
					}
					if(label.getLabelName().equals("tradingAmount")) {
						labelDetail.setTradingAmount(label.getValue());
					}
					if(label.getLabelName().equals("netAmount")) {
						labelDetail.setNetAmount(label.getValue());
					}
					if(label.getLabelName().equals("orderId")) {
						labelDetail.setOrderId(label.getValue());
					}
					if(label.getLabelName().equals("name")) {
						labelDetail.setName(label.getValue());
					}
					if(label.getLabelName().equals("catalogLabel")) {
						labelDetail.setCatalogLabel(label.getValue());
					}
					if(label.getLabelName().equals("remainQuantity")) {
						labelDetail.setRemainQuantity(label.getValue());
					}
					if(label.getLabelName().equals("partDetailId")) {
						labelDetail.setPartDetailId(label.getValue());
					}
					if(label.getLabelName().equals("addToCart")) {
						labelDetail.setAddToCart(label.getValue());
					}
					if(label.getLabelName().equals("moneyUnit")) {
						labelDetail.setMoneyUnit(label.getValue());
					}
					if(label.getLabelName().equals("orderConfirmHeader")) {
						labelDetail.setOrderConfirmHeader(label.getValue());
					}
					if(label.getLabelName().equals("taxInfo")) {
						labelDetail.setTaxInfo(label.getValue());
					}
					if(label.getLabelName().equals("searchCategoryHeader")) {
						labelDetail.setSearchCategoryHeader(label.getValue());
					}
					if(label.getLabelName().equals("selectYear")) {
						labelDetail.setSelectYear(label.getValue());
					}
					if(label.getLabelName().equals("selectMake")) {
						labelDetail.setSelectMake(label.getValue());
					}
					if(label.getLabelName().equals("selectModel")) {
						labelDetail.setSelectModel(label.getValue());
					}
					if(label.getLabelName().equals("deliveryTownship")) {
						labelDetail.setDeliveryTownship(label.getValue());
					}
				}
				labelDetailBean=labelDetail;
				for(ErrorMessage err:LabelAndErrorInfo.errorList) {
					if(err.getLanguage().equals(language)) {
						
						if(err.getMessageName().equals("insertError")) {
							errorDetail.setInsertError(err.getMessageLabel());
						}
						if(err.getMessageName().equals("noData")) {
							errorDetail.setNoData(err.getMessageLabel());
						}
						
					}
					errorDetailBean=errorDetail;
				}
				
				 
			}
			System.out.println(labelDetailBean.getName()+" is home name"+labelDetailBean.getOrderId()+labelDetailBean.getTrackOrderHeader()+"part is "+labelDetailBean.getPart());
			return "/product-form.jsf?faces-redirect=true";
	}
	
	

}
