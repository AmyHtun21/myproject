package com.am.spring_jsf.controller;


import java.util.HashMap;
import java.util.Map;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.am.spring_jsf.bean.Brand;
import com.am.spring_jsf.bean.BrandCategoryPart;
import com.am.spring_jsf.bean.Category;
import com.am.spring_jsf.bean.CategoryItem;
import com.am.spring_jsf.bean.Parts;

@Scope(value = "session")

@Component(value = "onlineCatalogController")

@ELBeanName(value = "onlineCatalogController")


@Join(path = "/onlineCataglog", to = "/online-catalog.jsf")
public class OnlineCatalogController extends CommonController{
	
	final String FIND_ONLINE_CATLOG="http://localhost:8082/onLineCatList";
	
	final String FIND_COMM_SEARCH="http://localhost:8082/commonSearchList?";
	
	@Autowired
	 HomeController homeController;
	
	private BrandCategoryPart brandCategoryPart;
	
	private RestTemplate restTemplate = new RestTemplate();
	
	private Long year;
	
	private String make;
	
	private String model;
	
	private Long partId;
	
	private String partName;
	
	private Long brandId;
	
	private String brandName;
	
    static boolean partFlg=true;
	
    static boolean yearFlg=true;
	
    static boolean makeFlg=true;
	
    static boolean modelFlg=true;
	
    static boolean brandFlg=true;
	
	private String[] keyList= {"year","make","model","brandId","partId"};
	
	private CategoryItem catItem;
	
	private static HashMap<String, Object> paramMap=new HashMap<String,Object>();
	
	public OnlineCatalogController() {
	}
	
	 public String onLoad() {
		 System.out.println("Reach in Onload");
		 if(labelDetailBean==null) {
				return "/Language.xhtml?faces-redirect=true";
			}
	        RestTemplate restTemplate = new RestTemplate();
	        ResponseEntity<BrandCategoryPart> responseEntity = restTemplate.getForEntity(FIND_ONLINE_CATLOG, BrandCategoryPart.class);
	        brandCategoryPart = responseEntity.getBody();
	        homeController.setYear(null);
	        homeController.setMake(null);
	        homeController.setModel(null);
	        homeController.setMakeRender(false); 
	        homeController.setModelRender(false);
	        makeRenderFlg();
	        this.paramMap.clear();
	        return "/online-catalog.xhtml";
	 }
	 
	 public String searchWithBrandAndPart(Long brandId,Long partId) {
		 this.brandId=brandId;
		 this.partId=partId;
		 String callUrl=FIND_COMM_SEARCH+"brand="+brandId+"&&partId="+partId;
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 } 
	 
	 public String searchWtihMakeAndModel(Category category) {
		 this.make=category.getMake();
		 this.model=category.getModel();
		 this.partId=null;
		 this.brandId=null;
		 this.year=null;
		 this.paramMap.put(keyList[1], make);
		 this.paramMap.put(keyList[2], model);
		 String callUrl=makeUrl();
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 }
	 
	 public String searchWithYear(Long year) {
		 this.paramMap.put(keyList[0], year);
		 this.year=year;
		 String callUrl=makeUrl();
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl.toString());
		 return "/online-catalog-detail.xhtml";
	 }
	 
	 public String searchWithMake(String make) {
		 this.make=make;
		 this.paramMap.put(keyList[1], make);
		 String callUrl=makeUrl();
		 
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 }
	 
	 public String searchWithModel(String model) {
		 this.model=model;
		 System.out.println("Param value is"+paramMap+" and model value is "+model);
		 this.paramMap.put(keyList[2], model);
		 String callUrl=makeUrl();
		 
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 }
	 
	 public String searchWtihPart(Parts part) {
		 this.partId=part.getPartId();
		 this.partName=part.getPartName();
		 this.paramMap.put(keyList[4], partId);
		 String callUrl=makeUrl();
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 }
	 
	 public String searchWtihBrand(Brand brand) {
		 this.brandId=brand.getBrandId();
		 this.brandName=brand.getBrandName();
		 this.paramMap.put(keyList[3], brandId);
		 String callUrl=makeUrl();
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 }
	 
		public String searchByCategory() {
			this.year=homeController.getYear();
			this.make=homeController.getMake();
			this.model=homeController.getModel();
			 this.paramMap.put(keyList[0], homeController.getYear());
			 this.paramMap.put(keyList[1], homeController.getMake());
			 this.paramMap.put(keyList[2], homeController.getModel());
			 String callUrl=makeUrl();
			 System.out.println("This is call url"+callUrl);
			 brandCategoryPart=searchCommon(callUrl);
		   	 return "/online-catalog-detail.xhtml";
		
		}

	 
	 public String makeUrl() {
		 StringBuffer callUrl=null;
		 System.out.println(paramMap);
		 for(String key:paramMap.keySet()) 
		 { 
				 if(callUrl==null) {
					 callUrl=new StringBuffer(FIND_COMM_SEARCH+key+"="+paramMap.get(key));
				 }
				 else {
				 callUrl.append("&&"+key+"="+paramMap.get(key));
				 }
				 System.out.println("Enter in map"+key);
				 if(key.equals(keyList[0])) {
					this.yearFlg=false; 
				 }
				 if(key.equals(keyList[1])) {
					 this.makeFlg=false;
				 }
				 if(key.equals(keyList[2])) {
					 this.modelFlg=false;
				 }
				 if(key.equals(keyList[3])) {
					 this.brandFlg=false;
				 }
				 if(key.equals(keyList[4])) {
					 this.partFlg=false;
				 }
		 }
		return callUrl.toString();
	 }
	 
	 public String searchWtihMakeAndModelAndBrand(Long brandId) {
		 this.partFlg=true;
		 this.brandFlg=false;
		 this.yearFlg=true;
		 this.makeFlg=false;
		 this.modelFlg=false;
		 this.brandId=brandId;
		 this.paramMap.put("brandId", brandId);
		 String callUrl=makeUrl();
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 }
	 

	 
	 public String searchWtihMakeAndModelAndBrandPart(Long partId) {
		 this.brandFlg=false;
		 this.yearFlg=true;
		 this.makeFlg=false;
		 this.modelFlg=false;
		 this.partFlg=false;
		 this.partId=partId;
		 this.paramMap.put("partId", partId);
		 String callUrl=makeUrl();
		 System.out.println("This is call url"+callUrl);
		 brandCategoryPart=searchCommon(callUrl);
		 return "/online-catalog-detail.xhtml";
	 }
	 

	 
	 public BrandCategoryPart searchCommon(String callUrl) {
		 ResponseEntity<BrandCategoryPart> responseEntity=restTemplate.getForEntity(callUrl, BrandCategoryPart.class);
		 BrandCategoryPart brandCategoryPart=responseEntity.getBody();
		 return brandCategoryPart;
	 }
	 
	 public static void makeRenderFlg() {
		 brandFlg=true;
		 yearFlg=true;
		 makeFlg=true;
		 modelFlg=true;
		 partFlg=true;
	 }

	public BrandCategoryPart getBrandCategoryPart() {
		return brandCategoryPart;
	}

	public void setBrandCategoryPart(BrandCategoryPart brandCategoryPart) {
		this.brandCategoryPart = brandCategoryPart;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public Long getPartId() {
		return partId;
	}

	public void setPartId(Long partId) {
		this.partId = partId;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public boolean isPartFlg() {
		return partFlg;
	}

	public void setPartFlg(boolean partFlg) {
		this.partFlg = partFlg;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public Long getBrandId() {
		return brandId;
	}

	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}

	public boolean isYearFlg() {
		return yearFlg;
	}

	public void setYearFlg(boolean yearFlg) {
		this.yearFlg = yearFlg;
	}

	public boolean isMakeFlg() {
		return makeFlg;
	}

	public void setMakeFlg(boolean makeFlg) {
		this.makeFlg = makeFlg;
	}

	public boolean isModelFlg() {
		return modelFlg;
	}

	public void setModelFlg(boolean modelFlg) {
		this.modelFlg = modelFlg;
	}

	public boolean isBrandFlg() {
		return brandFlg;
	}

	public void setBrandFlg(boolean brandFlg) {
		this.brandFlg = brandFlg;
	}

	public static HashMap<String, Object> getParamMap() {
		return paramMap;
	}

	public static void setParamMap(HashMap<String, Object> paramMap) {
		OnlineCatalogController.paramMap = paramMap;
	}

	public CategoryItem getCatItem() {
		return catItem;
	}

	public void setCatItem(CategoryItem catItem) {
		this.catItem = catItem;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	 
	 
}
