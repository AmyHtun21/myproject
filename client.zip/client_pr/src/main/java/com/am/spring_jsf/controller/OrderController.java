package com.am.spring_jsf.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.am.spring_jsf.bean.CategoryItem;
import com.am.spring_jsf.bean.Customer;
import com.am.spring_jsf.bean.ErrorMessage;
import com.am.spring_jsf.bean.FullCategoryDetail;
import com.am.spring_jsf.bean.OrderDetailInfo;
import com.am.spring_jsf.bean.OrderInfo;
import com.am.spring_jsf.bean.OrderLists;
import com.am.spring_jsf.bean.SellOrder;

@Scope(value="session")
@Component("orderController")
@ELBeanName("orderController")
@Join(path="/orders",to="order-confirm.jsf")
public class OrderController extends CommonController{
	
	private String ORDER_CONFIRM="http://localhost:8082/comfirmOrder/";
	
	private String ORDER_SUBMIT="http://localhost:8082/insertOrder/";
	
	private final String CATEGORY_LIST="http://localhost:8082/categoryItem";
	
	private final String ORDER_SEARCH="http://localhost:8082/searchNewOrders";
	
	private Double deliveryFees;
	
	private SellOrder sellOrder;
	
	private Customer customer;
	
	private OrderDetailInfo orderDetailInfo;
	
	private int buyQty=1;
	
	private String deliveryId;
	
	private Long categoryDetailId;
	
	private List<OrderInfo> orderInfoList;
	
	private OrderLists insertedOrderList;
	
	private String customerName;
	private String customerPhone;
	private String customerEmail;
	private String customerAddress;
	private Long   sellOrdreId;
	private RestTemplate restTemplate = new RestTemplate();
	
	private CategoryItem catItem;
	
	private BigDecimal totalAmount;
	
	private String errorMessage ;
	
	private Boolean orderListFlg;
	
	private Boolean errorFlg;
	
	@Autowired
	private HomeController homeController;
	

	private List<OrderDetailInfo> cartList=new ArrayList<OrderDetailInfo>();
	
	public String onLoad() {
		if(labelDetailBean==null) {
			return "/Language.xhtml?faces-redirect=true";
		}
		OnlineCatalogController.makeRenderFlg();
		System.out.println(cartList.size()+" is cartList size");
		if(cartList==null || cartList.size()==0) {
		this.orderListFlg=false;
		this.errorMessage=errorDetailBean.getNoData();
		this.errorFlg=true;
		 return "/order-confirm.xhtml";
		}
		else {
			this.orderListFlg=true;
			this.errorFlg=false;
		}
		System.out.println("Reach in order onload method");
		this.customerName=null;
		this.customerPhone=null;
		this.customerEmail=null;
		this.customerAddress=null;
		this.sellOrdreId=null;
		 return "/order-confirm.xhtml";
	}
	
	public String onLoadDetail() {
		if(labelDetailBean==null) {
			return "/Language.xhtml?faces-redirect=true";
		}
		this.buyQty=1;
		 return "/online-catalog-detail.xhtml";
	}
	
	public String onLoadCheckOut() {
		if(labelDetailBean==null) {
			return "/Language.xhtml?faces-redirect=true";
		}
	//	this.errorMessageFlg=false;
		return "/check-out.xhtml";
	}
	
	public String searchCategory() {
		if(labelDetailBean==null) {
			return "/Language.xhtml?faces-redirect=true";
		}
		buyQty=1;
	   	 ResponseEntity<CategoryItem> catResponseEntity=restTemplate.getForEntity(CATEGORY_LIST, CategoryItem.class);
	   	 catItem=catResponseEntity.getBody();
	   	 System.out.println("final is"+catItem.getYear());
		return"/partdetail-list.xhtml";
	}
	
	public String searchOrders() {
		StringBuffer callUrl=new StringBuffer(ORDER_SEARCH);
		ResponseEntity<OrderInfo[]> responseEntity=restTemplate.getForEntity(callUrl.toString(), OrderInfo[].class);
		this.orderInfoList=Arrays.asList(responseEntity.getBody());
		 return "/track-order.xhtml";
	}
	
	public String orderCancel(OrderDetailInfo orderDetailInfo) {
		List<OrderDetailInfo> updatedOrderDetailList=new ArrayList<OrderDetailInfo>();
		for(OrderDetailInfo orderDetail:cartList) {
			if(orderDetailInfo.toString().equals(orderDetail.toString())) {
				continue;
			}
			updatedOrderDetailList.add(orderDetail);
		}
		cartList=updatedOrderDetailList;
		updatedOrderDetailList=null;
		return "/order-confirm.xhtml?faces-redirect=true";
		
	}
	
	public String orderConfirm(FullCategoryDetail categoryDetail) {
		System.out.println("Order Confirm Test is "+buyQty+deliveryId);
		SellOrder order=new SellOrder();
		order.setCategoryDetailId(categoryDetail.getCategoryDetailId());
		System.out.println("Reach 1"+categoryDetail.getCategoryDetailId());
		order.setSellQuantity(new BigDecimal(buyQty));
		System.out.println("Reach 2"+buyQty);
		order.setSellPrice(categoryDetail.getCurrentSellingPrice());
		System.out.println("Reach 3"+categoryDetail.getCurrentSellingPrice());
		order.setDeliveryId(deliveryId);
		System.out.println("Reach 4"+deliveryId);
		OrderDetailInfo orderDetailInfo=restTemplate.postForObject(
				ORDER_CONFIRM,
				order,
				OrderDetailInfo.class);
		System.out.println("Reach 7"+orderDetailInfo.getOrder().getSellOrderId());
		
	 	orderDetailInfo.setCategoryDetail(categoryDetail);
	 	
		cartList.add(orderDetailInfo);
		System.out.println("Order Detail Info Test is "+cartList);
		this.buyQty=1;

	     return "/order-confirm.xhtml?faces-redirect=true";
		
	}
	
	public String checkOut() {
		System.out.println("Reach in Check OUt");
		
		return "/check-out.xhtml";
	}
	
	public String submitOrders() {
		StringBuffer errorBuffer=new StringBuffer();
		System.out.println("Reach in Submit");
		if(customerName==null || customerName.equals("")) {
			errorBuffer.append(labelDetailBean.getName());
		}
		if(customerPhone==null || customerPhone.equals(""))
		{
			errorBuffer.append(labelDetailBean.getPhoneNo());
		}
		if(customerAddress==null || customerAddress.equals(""))
		{
			errorBuffer.append(labelDetailBean.getAddress());
		}
		if(deliveryId==null || deliveryId.equals(""))
		{
			errorBuffer.append(labelDetailBean.getDeliveryTownship());
		}
		if(errorBuffer.length() > 1) {
			errorMessage=errorDetailBean.getNoData().replace("{0}", errorBuffer);
			this.errorFlg=true;
			return "/check-out.xhtml?faces-redirect=true";
		}
		OrderLists orderList=new OrderLists();
		customer=new Customer();
		customer.setCustomerAddress(customerAddress);
		customer.setCustomerEmail(customerEmail);
		customer.setCustomerName(customerName);
		customer.setCustomerPhone(customerPhone);
		orderList.setCustomer(customer);
		orderList.setOrderList(cartList);
		orderList.setDeliveryId(deliveryId);
		System.out.println("Delivery Id is"+deliveryId);
		RestTemplate restTemplate=new RestTemplate();
		totalAmount=new BigDecimal(0.0);
		 insertedOrderList=restTemplate.postForObject(
				ORDER_SUBMIT,
				orderList,
				OrderLists.class);
		System.out.println("total amount is "+insertedOrderList.getAllNetAmount());
		this.cartList.clear();
		this.errorFlg=false;
		return "/check-out-complete.xhtml";
	}

	
	public Double getDeliveryFees() {
		return deliveryFees;
	}

	public void setDeliveryFees(Double deliveryFees) {
		this.deliveryFees = deliveryFees;
	}

	public SellOrder getSellOrder() {
		return sellOrder;
	}

	public void setSellOrder(SellOrder sellOrder) {
		this.sellOrder = sellOrder;
	}

	public OrderDetailInfo getOrderDetailInfo() {
		return orderDetailInfo;
	}

	public void setOrderDetailInfo(OrderDetailInfo orderDetailInfo) {
		this.orderDetailInfo = orderDetailInfo;
	}
	
	
	public int getBuyQty() {
		return buyQty;
	}

	public void setBuyQty(int buyQty) {
		this.buyQty = buyQty;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public Long getCategoryDetailId() {
		return categoryDetailId;
	}

	public void setCategoryDetailId(Long categoryDetailId) {
		this.categoryDetailId = categoryDetailId;
	}

	public List<OrderDetailInfo> getCartList() {
		return cartList;
	}

	public void setCartList(List<OrderDetailInfo> cartList) {
		this.cartList = cartList;
	}


	public CategoryItem getCatItem() {
		return catItem;
	}


	public void setCatItem(CategoryItem catItem) {
		this.catItem = catItem;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getCustomerPhone() {
		return customerPhone;
	}


	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}


	public String getCustomerEmail() {
		return customerEmail;
	}


	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}


	public String getCustomerAddress() {
		return customerAddress;
	}


	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public List<OrderInfo> getOrderInfoList() {
		return orderInfoList;
	}

	public void setOrderInfoList(List<OrderInfo> orderInfoList) {
		this.orderInfoList = orderInfoList;
	}

	public Long getSellOrdreId() {
		return sellOrdreId;
	}

	public void setSellOrdreId(Long sellOrdreId) {
		this.sellOrdreId = sellOrdreId;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public OrderLists getInsertedOrderList() {
		return insertedOrderList;
	}

	public void setInsertedOrderList(OrderLists insertedOrderList) {
		this.insertedOrderList = insertedOrderList;
	}


	public Boolean getOrderListFlg() {
		return orderListFlg;
	}

	public void setOrderListFlg(Boolean orderListFlg) {
		this.orderListFlg = orderListFlg;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Boolean getErrorFlg() {
		return errorFlg;
	}

	public void setErrorFlg(Boolean errorFlg) {
		this.errorFlg = errorFlg;
	}




	
	

}
