package com.am.spring_jsf.bean;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class BrandCategoryPart {
	
	List<Parts> bestSellPartList;

	List<Brand> brandList;
	
	List<Category> categoryList;
	
	List<Parts> partList;
	
	List<FullCategoryDetail> fullDetailList;
	
	List<FullCategoryDetail> bestSellerDetailList;
	
	Set<Long> yearList;
	
	Set<String> makeList;
	
	Set<String> modelList;
	
	Map<String,BigDecimal> deliveryInfoList;
	
	List<LabelBean> labelList;
	
	CategoryItem catItem;
	
	public List<Brand> getBrandList() {
		return brandList;
	}

	public void setBrandList(List<Brand> brandList) {
		this.brandList = brandList;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public List<Parts> getPartList() {
		return partList;
	}

	public void setPartList(List<Parts> partList) {
		this.partList = partList;
	}

	public List<Parts> getBestSellPartList() {
		return bestSellPartList;
	}

	public void setBestSellPartList(List<Parts> bestSellPartList) {
		this.bestSellPartList = bestSellPartList;
	}

	public List<FullCategoryDetail> getFullDetailList() {
		return fullDetailList;
	}

	public void setFullDetailList(List<FullCategoryDetail> fullDetailList) {
		this.fullDetailList = fullDetailList;
	}

	public List<FullCategoryDetail> getBestSellerDetailList() {
		return bestSellerDetailList;
	}

	public void setBestSellerDetailList(List<FullCategoryDetail> bestSellerDetailList) {
		this.bestSellerDetailList = bestSellerDetailList;
	}




	public Set<Long> getYearList() {
		return yearList;
	}

	public void setYearList(Set<Long> yearList) {
		this.yearList = yearList;
	}

	public Set<String> getMakeList() {
		return makeList;
	}

	public void setMakeList(Set<String> makeList) {
		this.makeList = makeList;
	}

	public Set<String> getModelList() {
		return modelList;
	}

	public void setModelList(Set<String> modelList) {
		this.modelList = modelList;
	}

	public Map<String, BigDecimal> getDeliveryInfoList() {
		return deliveryInfoList;
	}

	public void setDeliveryInfoList(Map<String, BigDecimal> deliveryInfoList) {
		this.deliveryInfoList = deliveryInfoList;
	}

	public List<LabelBean> getLabelList() {
		return labelList;
	}

	public void setLabelList(List<LabelBean> labelList) {
		this.labelList = labelList;
	}

	public CategoryItem getCatItem() {
		return catItem;
	}

	public void setCatItem(CategoryItem catItem) {
		this.catItem = catItem;
	}




	

}
