package com.am.spring_jsf.bean;

public class LabelDetailBean {
	
	public static  String home;
	public static  String catalog;
	public static  String brand;
	public static  String customerService;
	public static  String track;
	public static  String view;
	public static  String checkOut;
	public static  String submit;
	public static  String cancel;
	public static  String year;
	public static  String model;
	public static  String make;
	public static  String part;
	public static  String position;
	public static  String condition;
	public static  String currentPrice;
	public static  String originalPrice;
	public static  String serviceTax;
	public static  String commercialTax;
	public static  String deliveryFee;
	public static  String totalCharge;
	public static  String address;
	public static  String phoneNo;
	public static  String name;
	public static  String email;
	public static  String brands;
	public static  String bestSellerParts;
	public static  String bestSellerBrands;
	public static  String shopMoreParts;
	public static  String shopByMake;
	public static  String search;
	public static  String trackOrderHeader;
	public static  String orderId;
	public static  String category;
	public static  String price;
	public static  String quantity;
	public static  String tradingAmount;
	public static  String netAmount;
	public static  String catalogLabel;
	public static  String remainQuantity;
	public static  String partDetailId;
	public static  String addToCart;
	public static  String moneyUnit;
	public static  String orderConfirmHeader;
	public static  String taxInfo;
	public static  String searchCategoryHeader;
	public static  String selectYear;
	public static  String selectMake;
	public static  String selectModel;
	public static String deliveryTownship;
	
	public  String getHome() {
		return home;
	}
	public  void setHome(String home) {
		LabelDetailBean.home = home;
	}
	public  String getCatalog() {
		return catalog;
	}
	public  void setCatalog(String catalog) {
		LabelDetailBean.catalog = catalog;
	}
	public  String getBrand() {
		return brand;
	}
	public  void setBrand(String brand) {
		LabelDetailBean.brand = brand;
	}
	public  String getCustomerService() {
		return customerService;
	}
	public  void setCustomerService(String customerService) {
		LabelDetailBean.customerService = customerService;
	}
	public  String getTrack() {
		return track;
	}
	public  void setTrack(String track) {
		LabelDetailBean.track = track;
	}
	public  String getView() {
		return view;
	}
	public  void setView(String view) {
		LabelDetailBean.view = view;
	}
	public  String getCheckOut() {
		return checkOut;
	}
	public  void setCheckOut(String checkOut) {
		LabelDetailBean.checkOut = checkOut;
	}
	public  String getSubmit() {
		return submit;
	}
	public  void setSubmit(String submit) {
		LabelDetailBean.submit = submit;
	}
	public  String getCancel() {
		return cancel;
	}
	public  void setCancel(String cancel) {
		LabelDetailBean.cancel = cancel;
	}
	public  String getYear() {
		return year;
	}
	public  void setYear(String year) {
		LabelDetailBean.year = year;
	}
	public  String getModel() {
		return model;
	}
	public  void setModel(String model) {
		LabelDetailBean.model = model;
	}
	public  String getMake() {
		return make;
	}
	public  void setMake(String make) {
		LabelDetailBean.make = make;
	}
	public  String getPart() {
		return part;
	}
	public  void setPart(String part) {
		LabelDetailBean.part = part;
	}
	public  String getPosition() {
		return position;
	}
	public  void setPosition(String position) {
		LabelDetailBean.position = position;
	}
	public  String getCondition() {
		return condition;
	}
	public  void setCondition(String condition) {
		LabelDetailBean.condition = condition;
	}
	public  String getCurrentPrice() {
		return currentPrice;
	}
	public  void setCurrentPrice(String currentPrice) {
		LabelDetailBean.currentPrice = currentPrice;
	}
	public  String getOriginalPrice() {
		return originalPrice;
	}
	public  void setOriginalPrice(String originalPrice) {
		LabelDetailBean.originalPrice = originalPrice;
	}
	public  String getServiceTax() {
		return serviceTax;
	}
	public  void setServiceTax(String serviceTax) {
		LabelDetailBean.serviceTax = serviceTax;
	}
	public  String getCommercialTax() {
		return commercialTax;
	}
	public  void setCommercialTax(String commercialTax) {
		LabelDetailBean.commercialTax = commercialTax;
	}
	public  String getDeliveryFee() {
		return deliveryFee;
	}
	public  void setDeliveryFee(String deliveryFee) {
		LabelDetailBean.deliveryFee = deliveryFee;
	}
	public  String getTotalCharge() {
		return totalCharge;
	}
	public  void setTotalCharge(String totalCharge) {
		LabelDetailBean.totalCharge = totalCharge;
	}
	public  String getAddress() {
		return address;
	}
	public  void setAddress(String address) {
		LabelDetailBean.address = address;
	}
	public  String getPhoneNo() {
		return phoneNo;
	}
	public  void setPhoneNo(String phoneNo) {
		LabelDetailBean.phoneNo = phoneNo;
	}
	public  String getName() {
		return name;
	}
	public  void setName(String name) {
		LabelDetailBean.name = name;
	}
	public  String getEmail() {
		return email;
	}
	public  void setEmail(String email) {
		LabelDetailBean.email = email;
	}
	public  String getBrands() {
		return brands;
	}
	public  void setBrands(String brands) {
		LabelDetailBean.brands = brands;
	}
	public  String getBestSellerParts() {
		return bestSellerParts;
	}
	public  void setBestSellerParts(String bestSellerParts) {
		LabelDetailBean.bestSellerParts = bestSellerParts;
	}
	public  String getBestSellerBrands() {
		return bestSellerBrands;
	}
	public  void setBestSellerBrands(String bestSellerBrands) {
		LabelDetailBean.bestSellerBrands = bestSellerBrands;
	}
	public  String getShopMoreParts() {
		return shopMoreParts;
	}
	public  void setShopMoreParts(String shopMoreParts) {
		LabelDetailBean.shopMoreParts = shopMoreParts;
	}
	public  String getShopByMake() {
		return shopByMake;
	}
	public  void setShopByMake(String shopByMake) {
		LabelDetailBean.shopByMake = shopByMake;
	}
	public  String getSearch() {
		return search;
	}
	public  void setSearch(String search) {
		LabelDetailBean.search = search;
	}
	public  String getTrackOrderHeader() {
		return trackOrderHeader;
	}
	public  void setTrackOrderHeader(String trackOrderHeader) {
		LabelDetailBean.trackOrderHeader = trackOrderHeader;
	}
	public  String getOrderId() {
		return orderId;
	}
	public  void setOrderId(String orderId) {
		LabelDetailBean.orderId = orderId;
	}
	public  String getCategory() {
		return category;
	}
	public  void setCategory(String category) {
		LabelDetailBean.category = category;
	}
	public  String getPrice() {
		return price;
	}
	public  void setPrice(String price) {
		LabelDetailBean.price = price;
	}
	public  String getQuantity() {
		return quantity;
	}
	public  void setQuantity(String quantity) {
		LabelDetailBean.quantity = quantity;
	}
	public  String getTradingAmount() {
		return tradingAmount;
	}
	public  void setTradingAmount(String tradingAmount) {
		LabelDetailBean.tradingAmount = tradingAmount;
	}
	public  String getNetAmount() {
		return netAmount;
	}
	public  void setNetAmount(String netAmount) {
		LabelDetailBean.netAmount = netAmount;
	}
	public  String getCatalogLabel() {
		return catalogLabel;
	}
	public  void setCatalogLabel(String catalogLabel) {
		LabelDetailBean.catalogLabel = catalogLabel;
	}
	public  String getRemainQuantity() {
		return remainQuantity;
	}
	public  void setRemainQuantity(String remainQuantity) {
		LabelDetailBean.remainQuantity = remainQuantity;
	}
	public  String getPartDetailId() {
		return partDetailId;
	}
	public  void setPartDetailId(String partDetailId) {
		LabelDetailBean.partDetailId = partDetailId;
	}
	public  String getAddToCart() {
		return addToCart;
	}
	public  void setAddToCart(String addToCart) {
		LabelDetailBean.addToCart = addToCart;
	}
	public  String getMoneyUnit() {
		return moneyUnit;
	}
	public  void setMoneyUnit(String moneyUnit) {
		LabelDetailBean.moneyUnit = moneyUnit;
	}
	public  String getOrderConfirmHeader() {
		return orderConfirmHeader;
	}
	public  void setOrderConfirmHeader(String orderConfirmHeader) {
		LabelDetailBean.orderConfirmHeader = orderConfirmHeader;
	}
	public  String getTaxInfo() {
		return taxInfo;
	}
	public  void setTaxInfo(String taxInfo) {
		LabelDetailBean.taxInfo = taxInfo;
	}
	public  String getSearchCategoryHeader() {
		return searchCategoryHeader;
	}
	public  void setSearchCategoryHeader(String searchCategoryHeader) {
		LabelDetailBean.searchCategoryHeader = searchCategoryHeader;
	}
	public  String getSelectYear() {
		return selectYear;
	}
	public  void setSelectYear(String selectYear) {
		LabelDetailBean.selectYear = selectYear;
	}
	public  String getSelectMake() {
		return selectMake;
	}
	public  void setSelectMake(String selectMake) {
		LabelDetailBean.selectMake = selectMake;
	}
	public  String getSelectModel() {
		return selectModel;
	}
	public  void setSelectModel(String selectModel) {
		LabelDetailBean.selectModel = selectModel;
	}
	public  String getDeliveryTownship() {
		return deliveryTownship;
	}
	public  void setDeliveryTownship(String deliveryTownship) {
		LabelDetailBean.deliveryTownship = deliveryTownship;
	}
	
	

}
