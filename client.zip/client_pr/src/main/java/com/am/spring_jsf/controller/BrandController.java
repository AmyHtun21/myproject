package com.am.spring_jsf.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.am.spring_jsf.bean.Brand;
import com.am.spring_jsf.bean.BrandCategoryPart;

@Scope(value = "session")

@Component(value = "brandController")

@ELBeanName(value = "brandController")

@Join(path = "/brand", to = "/brand-master.jsf")
public class BrandController extends CommonController{
	 final String BRAND_ALL = "http://localhost:8082/brandActiveList";
	 
	 final String BRAND_WITH_ID="http://localhost:8082/brandMasterList?brandId=";
	 
	 private Map<String,Object> keyMap=new HashMap<String,Object>();
	 
	 private List<Brand> brandList=null;
	 
	 private Brand selectedBrand;
	 
	 private BrandCategoryPart brandCatetoryPart;
	 
	 @Autowired
	 HomeController homeController;
	 
	 public String searchByBrandId(Brand b) {
		 
		 keyMap.clear();
		 System.out.println("Brand is "+b);
		 keyMap.put("brandName", b.getBrandName());
		 keyMap.put("brandId", b.getBrandId());
		 RestTemplate restTemp=new RestTemplate();
		 ResponseEntity<BrandCategoryPart> responseEntity = restTemp.getForEntity(BRAND_WITH_ID+b.getBrandId(), BrandCategoryPart.class);
		 brandCatetoryPart=responseEntity.getBody();
		 selectedBrand=b;
		 return "/brand-parts.xhtml";
	 }
	 
public String searchByBrandIdAndYear(Long year) {
		 
		 keyMap.put("year", year);
		 RestTemplate restTemp=new RestTemplate();
		 ResponseEntity<BrandCategoryPart> responseEntity = restTemp.getForEntity(BRAND_WITH_ID+keyMap.get("brandId")+"&&year="+year, BrandCategoryPart.class);
		 brandCatetoryPart=responseEntity.getBody();
		 return "/brand-parts.xhtml";
	 }
	 

	public List<Brand> getBrandList() {
		return brandList;
	}

	public void setBrandList(List<Brand> brandList) {
		this.brandList = brandList;
	}
	 
	 
	 public String onLoad() {
		 if(labelDetailBean==null) {
				return "/Language.xhtml?faces-redirect=true";
			}
		 OnlineCatalogController.makeRenderFlg();
	        RestTemplate restTemplate = new RestTemplate();
	        ResponseEntity<Brand[]> responseEntity = restTemplate.getForEntity(BRAND_ALL, Brand[].class);
	        Brand[] brandArray = responseEntity.getBody();
	        brandList=Arrays.asList(brandArray);
	        homeController.setYear(null);
	        homeController.setMake(null);
	        homeController.setModel(null);
	        homeController.setMakeRender(false);
	        homeController.setModelRender(false);
	        OnlineCatalogController.getParamMap().clear();
	        return "/brand-master.xhtml";
	 }
	 

	public BrandCategoryPart getBrandCatetoryPart() {
		return brandCatetoryPart;
	}


	public void setBrandCatetoryPart(BrandCategoryPart brandCatetoryPart) {
		this.brandCatetoryPart = brandCatetoryPart;
	}


	public Brand getSelectedBrand() {
		return selectedBrand;
	}


	public void setSelectedBrand(Brand selectedBrand) {
		this.selectedBrand = selectedBrand;
	}


	public Map<String, Object> getKeyMap() {
		return keyMap;
	}


	public void setKeyMap(Map<String, Object> keyMap) {
		this.keyMap = keyMap;
	}






	 
	 
}
