package com.am.spring_jsf.bean;

import java.util.List;

public class InitialBean {
	List<ErrorMessage> errorList;
	List<LabelBean> labelList;
	public List<ErrorMessage> getErrorList() {
		return errorList;
	}
	public void setErrorList(List<ErrorMessage> errorList) {
		this.errorList = errorList;
	}
	public List<LabelBean> getLabelList() {
		return labelList;
	}
	public void setLabelList(List<LabelBean> labelList) {
		this.labelList = labelList;
	}
	
	
	

}
