package com.ah.admin.bean;

public class Parts {

	private Long partId;
	private String partName;
	private String partSmallImage;
	private String partBigImage;
	private String partNote;
	private String partDeleteFlg;
	
	public Parts() {}
	public Parts(Long partId,String partName,String partSmalImage,String partBigImage,String partNote,String pDeleteFlg) {
		this.partId=partId;
		this.partName=partName;
		this.partSmallImage=partSmalImage;
		this.partBigImage=partBigImage;
		this.partNote=partNote;
		this.partDeleteFlg=pDeleteFlg;
	}
	public Long getPartId() {
		return partId;
	}
	public void setPartId(Long partId) {
		this.partId = partId;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	public String getPartSmallImage() {
		return partSmallImage;
	}
	public void setPartSmallImage(String partSmallImage) {
		this.partSmallImage = partSmallImage;
	}
	public String getPartBigImage() {
		return partBigImage;
	}
	public void setPartBigImage(String partBigImage) {
		this.partBigImage = partBigImage;
	}
	public String getPartNote() {
		return partNote;
	}
	public void setPartNote(String partNote) {
		this.partNote = partNote;
	}
	public String getPartDeleteFlg() {
		return partDeleteFlg;
	}
	public void setPartDeleteFlg(String partDeleteFlg) {
		this.partDeleteFlg = partDeleteFlg;
	}
	

	
	
	

}
