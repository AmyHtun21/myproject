package com.ah.admin.bean;

import java.math.BigDecimal;

public class Tax {
	String taxName;
	BigDecimal taxValue;
	public String getTaxName() {
		return taxName;
	}
	public void setTaxName(String taxName) {
		this.taxName = taxName;
	}
	public BigDecimal getTaxValue() {
		return taxValue;
	}
	public void setTaxValue(BigDecimal taxValue) {
		this.taxValue = taxValue;
	}
	
	

}
