package com.ah.admin.bean;

public class ErrorDetailBean {
	
	public static String noData;
	public static String insertError;
	
	public   String getNoData() {
		return noData;
	}
	public  void setNoData(String noData) {
		ErrorDetailBean.noData = noData;
	}
	public  String getInsertError() {
		return insertError;
	}
	public  void setInsertError(String insertError) {
		ErrorDetailBean.insertError = insertError;
	}
	
	

}
