package com.ah.admin.controller;

import java.util.Arrays;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ah.admin.bean.Admin;
import com.ah.admin.bean.BrandCategoryPart;
import com.ah.admin.bean.OrderInfo;
import com.ah.admin.bean.SellOrder;
import com.ah.admin.bean.Session;

@Scope(value = "session")

@Component(value = "lController")

@ELBeanName(value = "lController")

@Join(path = "/login", to = "/login.jsf")
public class LoginController {
	
	final String LOGIN = "http://localhost:8082/login?";
	
	final String SELL_ORDER_LIST = "http://localhost:8082/sellOrderInfoList";
	
	private String userName;

	private String password;
	
	private Admin admin;
	
	private BrandCategoryPart homePart;
	
	private List<OrderInfo> sellOrderInfoList;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	
	
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public String login() {
		System.out.println("Reach in login method");

FacesContext fCtx = FacesContext.getCurrentInstance();
HttpSession httpSession = (HttpSession) fCtx.getExternalContext().getSession(false);
String sessionId = httpSession.getId();
		RestTemplate restTemplate=new RestTemplate();
		System.out.println(LOGIN+"userName="+userName+"&&password="+password+"&&sessionId="+sessionId);
		ResponseEntity<Session> responseEntity=restTemplate.getForEntity(LOGIN+"userName="+userName+"&&password="+password+"&&sessionId="+sessionId,Session.class );
		Session session=responseEntity.getBody();
		if(session !=null && session.getUserName().equals(userName)) {
			ResponseEntity<OrderInfo[]> dataObj=restTemplate.getForEntity(SELL_ORDER_LIST,OrderInfo[].class);
			sellOrderInfoList=Arrays.asList(dataObj.getBody());
		}
		return "/home.xhtml";
	}

	public BrandCategoryPart getHomePart() {
		return homePart;
	}

	public void setHomePart(BrandCategoryPart homePart) {
		this.homePart = homePart;
	}

	public List<OrderInfo> getSellOrderInfoList() {
		return sellOrderInfoList;
	}

	public void setSellOrderInfoList(List<OrderInfo> sellOrderInfoList) {
		this.sellOrderInfoList = sellOrderInfoList;
	}


	

}
