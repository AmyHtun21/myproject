package com.ah.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.faces.event.ActionEvent;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ah.admin.bean.OrderStatus;
import com.ah.admin.bean.Parts;

@Scope(value = "session")

@Component(value = "partController")

@ELBeanName(value = "partController")

@Join(path = "/part", to = "/part.jsf")
public class PartController {
	
	RestTemplate template = new RestTemplate();
	
	private static final String PART_LIST="http://localhost:8082/partsActiveList";
	
	private static final String PART_ADD = "http://localhost:8082/insertParts";

	private static final String PART_UPDATE = "http://localhost:8082/updateParts";

	private static final String SAMPLE_XLSX_FILE_PATH = "Insert.xlsx";
	
	private List<Parts> partList;
	
	private Parts updatePart=new Parts();
	
	private String checkOneOrMore;
	
	public String onLoad() {
		updatePart.setPartId(null);
		updatePart.setPartName(null);
		updatePart.setPartSmallImage(null);
		updatePart.setPartBigImage(null);
		updatePart.setPartNote(null);
		updatePart.setPartDeleteFlg(null);
		ResponseEntity<Parts[]> partResponse=template.getForEntity(PART_LIST, Parts[].class);
		partList=Arrays.asList(partResponse.getBody());
		return "/part.xhtml";
	}

	public void attrListener(ActionEvent event) {

		checkOneOrMore = (String) event.getComponent().getAttributes().get("checkOneOrMore");

	}

	public String goToInput() {
		return "/part-input.xhtml";
	}

	public String insert() {
		System.out.println("Reach in Part Insert");
		partList = new ArrayList<Parts>();
		if (checkOneOrMore.equals("more")) {
			try {
				Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));
				Sheet sheet = workbook.getSheetAt(2);
				for (Row row : sheet) {
					if (row.getCell(0).getStringCellValue() == null || row.getCell(0).getStringCellValue().equals("")) {
						continue;
					}
					Parts p = new Parts();
					p.setPartName(row.getCell(0).getStringCellValue());
					p.setPartSmallImage(row.getCell(1).getStringCellValue());
					p.setPartBigImage(row.getCell(2).getStringCellValue());
					p.setPartNote(row.getCell(3).getStringCellValue());
					p.setPartDeleteFlg(OrderStatus.ACTIVE);
					System.out.println("part id is " + p.getPartName());
					partList.add(p);
				}

			} catch (EncryptedDocumentException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (checkOneOrMore.equals("one")) {
			updatePart.setPartDeleteFlg(OrderStatus.ACTIVE);
			partList.add(updatePart);
		}

		RestTemplate template = new RestTemplate();
		ResponseEntity<Parts[]> entity = template.postForEntity(PART_ADD, partList, Parts[].class);
		partList = Arrays.asList(entity.getBody());
		System.out.println(partList + " is part List");
		return "/part-complete.xhtml";
	}

	public String update(Parts part) {
		System.out.println("Reach in Part Update");
		updatePart.setPartId(part.getPartId());
		updatePart.setPartSmallImage(part.getPartSmallImage());
		updatePart.setPartBigImage(part.getPartBigImage());
		updatePart.setPartDeleteFlg(part.getPartDeleteFlg());
		updatePart.setPartName(part.getPartName());
		updatePart.setPartNote(part.getPartNote());
		return "/part-update.xhtml";
	}

	public String updatePart() {
		RestTemplate template = new RestTemplate();
		ResponseEntity<Parts> entity = template.postForEntity(PART_UPDATE, updatePart, Parts.class);
		updatePart = entity.getBody();
		System.out.println(updatePart + " is part update");
		return "/part-complete.xhtml";
	}

	public String delete(Parts part) {
		System.out.println("Reach in Part Delete");
		part.setPartDeleteFlg(OrderStatus.DELETE);
		RestTemplate template = new RestTemplate();
		ResponseEntity<Parts> entity = template.postForEntity(PART_UPDATE, part, Parts.class);
		updatePart = entity.getBody();
		System.out.println(updatePart + " is part update");
		return "/part-complete.xhtml";
	}
	
	public List<Parts> getPartList() {
		return partList;
	}

	public void setPartList(List<Parts> partList) {
		this.partList = partList;
	}

	public Parts getUpdatePart() {
		return updatePart;
	}

	public void setUpdatePart(Parts updatePart) {
		this.updatePart = updatePart;
	}
	
	

}
