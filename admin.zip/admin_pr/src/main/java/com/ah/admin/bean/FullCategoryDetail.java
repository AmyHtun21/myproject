package com.ah.admin.bean;

import java.math.BigDecimal;

public class FullCategoryDetail{

	private Long categoryDetailId;
	private String position;
	private BigDecimal quantity;
	private BigDecimal buyingPrice;
	private BigDecimal originalSellingPrice;
	private String detailNote;
	private String condition;
	private String detailDeleteFlg;
	private String detailLargeImgPath;
	private String detailSmallImgPath;
	private BigDecimal currentSellingPrice;
	private Long discountPercent;
	private Long partId;
	private Long brandId;
	private Long categoryId;
	private Long year;
	private String make;
	private String model;
	private String brandName;
	private String partName;
	
	public FullCategoryDetail() {}
	
	public FullCategoryDetail(Long categoryDetailId,String position,BigDecimal quantity,BigDecimal buyingPrice,BigDecimal originalSellingPrice,String detailNote,String condition,String dDeleteFlg,String dLImgPath,String dSImgPath,BigDecimal currentSellingPrice,Long discountPercent,Long partId,Long brandId,Long categoryId,Long year,String make,String model,String brandName,String partName) {
		 this.categoryDetailId=categoryDetailId;
		 this.position=position;
		 this.quantity=quantity;
		 this.buyingPrice=buyingPrice;
		 this.originalSellingPrice=originalSellingPrice;
		 this.detailNote=detailNote;
		 this.condition=condition;
		 this.detailDeleteFlg=dDeleteFlg;
		 this.detailLargeImgPath=dLImgPath;
		 this.detailSmallImgPath=dSImgPath;
		 this.currentSellingPrice=currentSellingPrice;
		 this.discountPercent=discountPercent;
		 this.partId=partId;
		 this.brandId=brandId;
		 this.categoryId=categoryId;
		 this.year=year;
		 this.make=make;
		 this.model=model;
		 this.brandName=brandName;
		 this.partName=partName;
	}

	public Long getCategoryDetailId() {
		return categoryDetailId;
	}

	public void setCategoryDetailId(Long categoryDetailId) {
		this.categoryDetailId = categoryDetailId;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getBuyingPrice() {
		return buyingPrice;
	}

	public void setBuyingPrice(BigDecimal buyingPrice) {
		this.buyingPrice = buyingPrice;
	}

	public BigDecimal getOriginalSellingPrice() {
		return originalSellingPrice;
	}

	public void setOriginalSellingPrice(BigDecimal originalSellingPrice) {
		this.originalSellingPrice = originalSellingPrice;
	}



	public String getDetailNote() {
		return detailNote;
	}

	public void setDetailNote(String detailNote) {
		this.detailNote = detailNote;
	}

	public String getDetailDeleteFlg() {
		return detailDeleteFlg;
	}

	public void setDetailDeleteFlg(String detailDeleteFlg) {
		this.detailDeleteFlg = detailDeleteFlg;
	}

	public String getDetailLargeImgPath() {
		return detailLargeImgPath;
	}

	public void setDetailLargeImgPath(String detailLargeImgPath) {
		this.detailLargeImgPath = detailLargeImgPath;
	}

	public String getDetailSmallImgPath() {
		return detailSmallImgPath;
	}

	public void setDetailSmallImgPath(String detailSmallImgPath) {
		this.detailSmallImgPath = detailSmallImgPath;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getdDeleteFlg() {
		return detailDeleteFlg;
	}

	public void setdDeleteFlg(String dDeleteFlg) {
		this.detailDeleteFlg = dDeleteFlg;
	}

	public String getdLImgPath() {
		return detailLargeImgPath;
	}

	public void setdLImgPath(String dLImgPath) {
		this.detailLargeImgPath = dLImgPath;
	}

	public String getdSImgPath() {
		return detailSmallImgPath;
	}

	public void setdSImgPath(String dSImgPath) {
		this.detailSmallImgPath = dSImgPath;
	}

	public BigDecimal getCurrentSellingPrice() {
		return currentSellingPrice;
	}

	public void setCurrentSellingPrice(BigDecimal currentSellingPrice) {
		this.currentSellingPrice = currentSellingPrice;
	}

	public Long getDiscountPercent() {
		return discountPercent;
	}

	public void setDiscountPercent(Long discountPercent) {
		this.discountPercent = discountPercent;
	}

	public Long getPartId() {
		return partId;
	}

	public void setPartId(Long partId) {
		this.partId = partId;
	}

	public Long getBrandId() {
		return brandId;
	}

	public void setBrandId(Long brandId) {
		this.brandId = brandId;
	}

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}
	
	

}
