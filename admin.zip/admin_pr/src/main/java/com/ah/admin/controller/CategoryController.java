package com.ah.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.faces.event.ActionEvent;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ah.admin.bean.Brand;
import com.ah.admin.bean.Category;
import com.ah.admin.bean.OrderStatus;

@Scope(value = "session")

@Component(value = "categoryController")

@ELBeanName(value = "categoryController")

@Join(path = "/category", to = "/category.jsf")
public class CategoryController {
	
	RestTemplate template = new RestTemplate();
	
	private static final String CATEGORY_LIST="http://localhost:8082/categoryActiveList";
	

	private static final String CATEGORY_ADD = "http://localhost:8082/insertCategory";

	private static final String CATEGORY_UPDATE = "http://localhost:8082/updateCategory";

	private static final String SAMPLE_XLSX_FILE_PATH = "Insert.xlsx";
	
	private List<Category> categoryList;
	
	private Category updateCategory=new Category();
	
	private String checkOneOrMore;
	
	public String onLoad() {
		updateCategory.setCategoryId(null);
		updateCategory.setCategoryDeleteFlg(null);
		updateCategory.setYear(null);
		updateCategory.setMake(null);
		updateCategory.setModel(null);
		ResponseEntity<Category[]> categoryResponse=template.getForEntity(CATEGORY_LIST, Category[].class);
		categoryList=Arrays.asList(categoryResponse.getBody());
		return "/category.xhtml";
	}
	
	public void attrListener(ActionEvent event) {

		checkOneOrMore = (String) event.getComponent().getAttributes().get("checkOneOrMore");

	}

	public String goToInput() {
		return "/category-input.xhtml";
	}

	public String insert() {
		System.out.println("Reach in category Insert");
		categoryList = new ArrayList<Category>();
		if (checkOneOrMore.equals("more")) {
			try {
				Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));
				Sheet sheet = workbook.getSheetAt(0);
				for (Row row : sheet) {
					if (row.getCell(0).getStringCellValue() == null || row.getCell(0).getStringCellValue().equals("")) {
						continue;
					}
					Category c = new Category();
					c.setYear(Long.parseLong(row.getCell(0).getStringCellValue()));
					c.setMake(row.getCell(1).getStringCellValue());
					c.setModel(row.getCell(2).getStringCellValue());
					c.setCategoryDeleteFlg(OrderStatus.ACTIVE);
					System.out.println("category id is " + c.getYear());
					categoryList.add(c);
				}

			} catch (EncryptedDocumentException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (checkOneOrMore.equals("one")) {
			updateCategory.setCategoryDeleteFlg(OrderStatus.ACTIVE);
			categoryList.add(updateCategory);
		}

		RestTemplate template = new RestTemplate();
		ResponseEntity<Category[]> entity = template.postForEntity(CATEGORY_ADD, categoryList, Category[].class);
		categoryList = Arrays.asList(entity.getBody());
		System.out.println(categoryList + " is category List");
		return "/category-complete.xhtml";
	}

	public String update(Category category) {
		System.out.println("Reach in category Update");
		updateCategory.setCategoryId(category.getCategoryId());
		updateCategory.setCategoryDeleteFlg(category.getCategoryDeleteFlg());
		updateCategory.setYear(category.getYear());
		updateCategory.setMake(category.getMake());
		updateCategory.setModel(category.getModel());
		return "/category-update.xhtml";
	}

	public String updateCategory() {
		RestTemplate template = new RestTemplate();
		ResponseEntity<Category> entity = template.postForEntity(CATEGORY_UPDATE, updateCategory, Category.class);
		updateCategory = entity.getBody();
		System.out.println(updateCategory + " is category update");
		return "/category-complete.xhtml";
	}

	public String delete(Category category) {
		System.out.println("Reach in category Delete");
		category.setCategoryDeleteFlg(OrderStatus.DELETE);
		RestTemplate template = new RestTemplate();
		ResponseEntity<Category> entity = template.postForEntity(CATEGORY_UPDATE, category, Category.class);
		updateCategory = entity.getBody();
		System.out.println(updateCategory + " is category update");
		return "/category-complete.xhtml";
	}


	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public Category getUpdateCategory() {
		return updateCategory;
	}

	public void setUpdateCategory(Category updateCategory) {
		this.updateCategory = updateCategory;
	}

	public String getCheckOneOrMore() {
		return checkOneOrMore;
	}

	public void setCheckOneOrMore(String checkOneOrMore) {
		this.checkOneOrMore = checkOneOrMore;
	}
	
	

}
