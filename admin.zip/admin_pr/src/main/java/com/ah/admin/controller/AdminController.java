package com.ah.admin.controller;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope(value = "session")
@Component(value="")
@ELBeanName(value="")
@Join(path="/home",to="/home.jsf")
public class AdminController {
	
	

}
