package com.ah.admin.bean;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:Label_En.properties")
@ConfigurationProperties
public class LabelEngBean extends LabelBean{

}
