package com.ah.admin.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.faces.event.ActionEvent;

import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ah.admin.bean.Brand;
import com.ah.admin.bean.BrandCategoryPart;
import com.ah.admin.bean.Category;
import com.ah.admin.bean.CategoryDetail;
import com.ah.admin.bean.FullCategoryDetail;
import com.ah.admin.bean.Parts;
@Scope(value = "session")

@Component(value = "fullController")

@ELBeanName(value = "fullController")

@Join(path = "/fullDetail", to = "/full-detail.jsf")
public class FullDetailController extends CommonController{

	RestTemplate template = new RestTemplate();
	
	private static final String CATEGORY_DETAIL_LIST="http://localhost:8082/fullDetailActiveList";
	
	private final String MASTER_LIST="http://localhost:8082/masterList";
	
	private List<FullCategoryDetail> fullCategoryDetailList;
	
	private CategoryDetail updateCategoryDetail=new CategoryDetail();
	
	private List<Parts> partList;
	
	private List<Brand> brandList;
	
	private Long year;
	
	private String make;
	
	private String model;
	
	private boolean makeRender;
	
	private boolean modelRender;
	
	private com.ah.admin.bean.CategoryItem catItem;
	
	public String onLoad() {
		
		ResponseEntity<FullCategoryDetail[]> categoryResponse=template.getForEntity(CATEGORY_DETAIL_LIST, FullCategoryDetail[].class);
		fullCategoryDetailList=Arrays.asList(categoryResponse.getBody());
		return "/full-detail.xhtml";
	}
	
    public String  goToInput() {
    	System.out.println("Reach in search all");
    	 RestTemplate restTemplate = new RestTemplate();
    	 ResponseEntity<BrandCategoryPart> responseEntity=restTemplate.getForEntity(MASTER_LIST, BrandCategoryPart.class);
    	 BrandCategoryPart brandCategoryPart=responseEntity.getBody();
    	 catItem=brandCategoryPart.getCatItem();
    	 partList=brandCategoryPart.getPartList();
    	 brandList=brandCategoryPart.getBrandList();
    	 System.out.println("final is"+catItem.getYear());
    	 return "/full-detail-input.xhtml";
    	 }
    	
    public void onYearChange() {
    	System.out.println("Reach in onYearChange"+year);
    	this.make=null;
    	this.model=null;
        if(year !=null && !year.equals("")) {
        	catItem.setMakeData(catItem.getMakeMap().get(year));
        }
        else 
        {
        	catItem.setMakeData(new HashMap<String,String>());
        }
        setMakeRender(true);
        System.out.println("Make value is"+catItem.getMakeData()+isMakeRender());
    }
    
    public void onMakeChange() {
    	System.out.println("Reach in onMakeChange"+make);
    	this.model=null;
        if(make !=null && !make.equals("")) {
        //	catItem.setModelData(catItem.getModelMap().get(make));
        	Map<String,String> modelMap=new HashMap<String,String>();
        	for(Category c:catItem.getCategoryList()) {
        		if(c.getYear().equals(year)&&c.getMake().equals(make)) {
        			modelMap.put(c.getModel(), c.getModel());
        		}
        	}
        	catItem.setModelData(modelMap);
        }
        modelRender=true;
        System.out.println("Model value is"+catItem.getModelData());
    }

	public List<FullCategoryDetail> getFullCategoryDetailList() {
		return fullCategoryDetailList;
	}

	public void setFullCategoryDetailList(List<FullCategoryDetail> fullCategoryDetailList) {
		this.fullCategoryDetailList = fullCategoryDetailList;
	}

	public CategoryDetail getUpdateCategoryDetail() {
		return updateCategoryDetail;
	}

	public void setUpdateCategoryDetail(CategoryDetail updateCategoryDetail) {
		this.updateCategoryDetail = updateCategoryDetail;
	}

	public List<Parts> getPartList() {
		return partList;
	}

	public void setPartList(List<Parts> partList) {
		this.partList = partList;
	}

	public List<Brand> getBrandList() {
		return brandList;
	}

	public void setBrandList(List<Brand> brandList) {
		this.brandList = brandList;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public boolean isMakeRender() {
		return makeRender;
	}

	public void setMakeRender(boolean makeRender) {
		this.makeRender = makeRender;
	}

	public boolean isModelRender() {
		return modelRender;
	}

	public void setModelRender(boolean modelRender) {
		this.modelRender = modelRender;
	}

	public com.ah.admin.bean.CategoryItem getCatItem() {
		return catItem;
	}

	public void setCatItem(com.ah.admin.bean.CategoryItem catItem) {
		this.catItem = catItem;
	}

	public String getMASTER_LIST() {
		return MASTER_LIST;
	}


}
