package com.ah.admin.bean;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;


public class SellRecords implements Serializable{
	
	private BigDecimal sellOrderId;
	private BigDecimal categoryDetailId;
	private String adminConfirmFlg;
	private BigDecimal sellQuantity;
	private String cancellableFlg;
	private String executionFlg;
	private String orderCompleteFlg;
	private Timestamp orderTimestamp;
	private Timestamp updatedTimestamp;
	private Timestamp executionTimestamp;
	private Timestamp cancellationTimestamp;
	private String lastUpdater;
	private String note;
	private BigDecimal sellAmount;
	private String email;
	private BigDecimal phoneNo;
	private String deliveryId;
	private String address;
	public BigDecimal getSellOrderId() {
		return sellOrderId;
	}
	public void setSellOrderId(BigDecimal sellOrderId) {
		this.sellOrderId = sellOrderId;
	}
	public BigDecimal getCategoryDetailId() {
		return categoryDetailId;
	}
	public void setCategoryDetailId(BigDecimal categoryDetailId) {
		this.categoryDetailId = categoryDetailId;
	}
	public String getAdminConfirmFlg() {
		return adminConfirmFlg;
	}
	public void setAdminConfirmFlg(String adminConfirmFlg) {
		this.adminConfirmFlg = adminConfirmFlg;
	}
	public BigDecimal getSellQuantity() {
		return sellQuantity;
	}
	public void setSellQuantity(BigDecimal sellQuantity) {
		this.sellQuantity = sellQuantity;
	}
	public String getCancellableFlg() {
		return cancellableFlg;
	}
	public void setCancellableFlg(String cancellableFlg) {
		this.cancellableFlg = cancellableFlg;
	}
	public String getExecutionFlg() {
		return executionFlg;
	}
	public void setExecutionFlg(String executionFlg) {
		this.executionFlg = executionFlg;
	}
	public String getOrderCompleteFlg() {
		return orderCompleteFlg;
	}
	public void setOrderCompleteFlg(String orderCompleteFlg) {
		this.orderCompleteFlg = orderCompleteFlg;
	}
	public Timestamp getOrderTimestamp() {
		return orderTimestamp;
	}
	public void setOrderTimestamp(Timestamp orderTimestamp) {
		this.orderTimestamp = orderTimestamp;
	}
	public Timestamp getUpdatedTimestamp() {
		return updatedTimestamp;
	}
	public void setUpdatedTimestamp(Timestamp updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}
	public Timestamp getExecutionTimestamp() {
		return executionTimestamp;
	}
	public void setExecutionTimestamp(Timestamp executionTimestamp) {
		this.executionTimestamp = executionTimestamp;
	}
	public Timestamp getCancellationTimestamp() {
		return cancellationTimestamp;
	}
	public void setCancellationTimestamp(Timestamp cancellationTimestamp) {
		this.cancellationTimestamp = cancellationTimestamp;
	}
	public String getLastUpdater() {
		return lastUpdater;
	}
	public void setLastUpdater(String lastUpdater) {
		this.lastUpdater = lastUpdater;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public BigDecimal getSellAmount() {
		return sellAmount;
	}
	public void setSellAmount(BigDecimal sellAmount) {
		this.sellAmount = sellAmount;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public BigDecimal getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(BigDecimal phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	


}
