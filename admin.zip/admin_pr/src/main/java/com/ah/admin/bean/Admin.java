package com.ah.admin.bean;

public class Admin {
	
	private String userName;
	private String password;
	private String userDeleteFlg;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserDeleteFlg() {
		return userDeleteFlg;
	}
	public void setUserDeleteFlg(String userDeleteFlg) {
		this.userDeleteFlg = userDeleteFlg;
	}
	
	

}
