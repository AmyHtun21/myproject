package com.ah.admin.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.faces.event.ActionEvent;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.ocpsoft.rewrite.annotation.Join;
import org.ocpsoft.rewrite.el.ELBeanName;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ah.admin.bean.Brand;

@Scope(value = "session")

@Component(value = "brandController")

@ELBeanName(value = "brandController")

@Join(path = "/brand", to = "/brand.jsf")
public class BrandController {

	RestTemplate template = new RestTemplate();

	private static final String BRAND_LIST = "http://localhost:8082/brandActiveList";

	private static final String BRAND_ADD = "http://localhost:8082/insertBrand";

	private static final String BRAND_UPDATE = "http://localhost:8082/updateBrand";

	private static final String SAMPLE_XLSX_FILE_PATH = "Insert.xlsx";

	private List<Brand> brandList;

	private Brand updateBrand = new Brand();

	private String checkOneOrMore;

	public String onLoad() {
		updateBrand.setBrandId(null);
		updateBrand.setBrandName(null);
		updateBrand.setBrandImagePath(null);
		updateBrand.setBrandNote(null);
		ResponseEntity<Brand[]> brandResponse = template.getForEntity(BRAND_LIST, Brand[].class);
		brandList = Arrays.asList(brandResponse.getBody());
		return "/brand.xhtml";
	}

	public void attrListener(ActionEvent event) {

		checkOneOrMore = (String) event.getComponent().getAttributes().get("checkOneOrMore");

	}

	public String goToInput() {
		return "/brand-input.xhtml";
	}

	public String insert() {
		System.out.println("Reach in Brand Insert");
		brandList = new ArrayList<Brand>();
		if (checkOneOrMore.equals("more")) {
			try {
				Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));
				Sheet sheet = workbook.getSheetAt(0);
				for (Row row : sheet) {
					if (row.getCell(0).getStringCellValue() == null || row.getCell(0).getStringCellValue().equals("")) {
						continue;
					}
					Brand b = new Brand();
					b.setBrandName(row.getCell(0).getStringCellValue());
					b.setBrandImagePath(row.getCell(1).getStringCellValue());
					b.setBrandNote(row.getCell(2).getStringCellValue());
					b.setBrandDeleteFlg("0");
					System.out.println("brand id is " + b.getBrandName());
					brandList.add(b);
				}

			} catch (EncryptedDocumentException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (checkOneOrMore.equals("one")) {
			updateBrand.setBrandDeleteFlg("0");
			brandList.add(updateBrand);
		}

		RestTemplate template = new RestTemplate();
		ResponseEntity<Brand[]> entity = template.postForEntity(BRAND_ADD, brandList, Brand[].class);
		brandList = Arrays.asList(entity.getBody());
		System.out.println(brandList + " is brand List");
		return "/brand-complete.xhtml";
	}

	public String update(Brand brand) {
		System.out.println("Reach in Brand Update");
		updateBrand.setBrandId(brand.getBrandId());
		updateBrand.setBrandImagePath(brand.getBrandImagePath());
		updateBrand.setBrandDeleteFlg(brand.getBrandDeleteFlg());
		updateBrand.setBrandName(brand.getBrandName());
		updateBrand.setBrandNote(brand.getBrandNote());
		return "/brand-update.xhtml";
	}

	public String updateBrand() {
		RestTemplate template = new RestTemplate();
		ResponseEntity<Brand> entity = template.postForEntity(BRAND_UPDATE, updateBrand, Brand.class);
		updateBrand = entity.getBody();
		System.out.println(updateBrand + " is brand update");
		return "/brand-complete.xhtml";
	}

	public String delete(Brand brand) {
		System.out.println("Reach in Brand Delete");
		brand.setBrandDeleteFlg("1");
		RestTemplate template = new RestTemplate();
		ResponseEntity<Brand> entity = template.postForEntity(BRAND_UPDATE, brand, Brand.class);
		updateBrand = entity.getBody();
		System.out.println(updateBrand + " is brand update");
		return "/brand-complete.xhtml";
	}

	public List<Brand> getBrandList() {
		return brandList;
	}

	public void setBrandList(List<Brand> brandList) {
		this.brandList = brandList;
	}

	public Brand getUpdateBrand() {
		return updateBrand;
	}

	public void setUpdateBrand(Brand updateBrand) {
		this.updateBrand = updateBrand;
	}

	public boolean checkFileExists(String filePath) {
		File file = new File(filePath);
		if (file.exists()) {
			return true;
		}
		return false;

	}

	public String getCheckOneOrMore() {
		return checkOneOrMore;
	}

	public void setCheckOneOrMore(String checkOneOrMore) {
		this.checkOneOrMore = checkOneOrMore;
	}

}
