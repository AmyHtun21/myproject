package com.ah.admin.bean;

public class OrderStatus {
	
	public static String NEW="0";
	public static String COMPLETE="1";
	public static String ACTIVE="0";
	public static String DELETE="1";

}
