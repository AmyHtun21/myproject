package com.ah.admin.bean;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class OrderDetailInfo {
	
	private SellOrder order;
	private FullCategoryDetail categoryDetail;
	private List<Tax> tax;
	private BigDecimal deliveryFee;
	private String deliveryId;
	private Map<String,BigDecimal[]> taxMap;
	private BigDecimal totalTax;
	private BigDecimal totalAmount;
	private String errMesage;
	public SellOrder getOrder() {
		return order;
	}
	public void setOrder(SellOrder order) {
		this.order = order;
	}
	public FullCategoryDetail getCategoryDetail() {
		return categoryDetail;
	}
	public void setCategoryDetail(FullCategoryDetail categoryDetail) {
		this.categoryDetail = categoryDetail;
	}
	public List<Tax> getTax() {
		return tax;
	}
	public void setTax(List<Tax> tax) {
		this.tax = tax;
	}
	public BigDecimal getDeliveryFee() {
		return deliveryFee;
	}
	public void setDeliveryFee(BigDecimal deliveryFee) {
		this.deliveryFee = deliveryFee;
	}
	public String getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
	public BigDecimal getTotalTax() {
		return totalTax;
	}
	public void setTotalTax(BigDecimal totalTax) {
		this.totalTax = totalTax;
	}
	public BigDecimal getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getErrMesage() {
		return errMesage;
	}
	public void setErrMesage(String errMesage) {
		this.errMesage = errMesage;
	}
	public Map<String, BigDecimal[]> getTaxMap() {
		return taxMap;
	}
	public void setTaxMap(Map<String, BigDecimal[]> taxMap) {
		this.taxMap = taxMap;
	}
	
	public String toString() {
		return order.getSellOrderId()+""+categoryDetail.getCategoryDetailId();
	}
	
	
	
}
