package com.ah.admin.bean;

import java.math.BigDecimal;

public class CategoryDetail{
	
	private BigDecimal categoryDetailId;
	private String position;
	private BigDecimal quantity;
	private BigDecimal buyingPrice;
	private BigDecimal originalSellingPrice;
	private String detailNote;
	private String condition;
	private String detailDeleteFlg;
	private String detailLargeImgPath;
	private String detailSmallImgPath;
	private BigDecimal currentSellingPrice;
	private BigDecimal discountPercent;
	private BigDecimal partId;
	private BigDecimal brandId;
	private BigDecimal categoryId;
	public BigDecimal getCategoryDetailId() {
		return categoryDetailId;
	}
	public void setCategoryDetailId(BigDecimal categoryDetailId) {
		this.categoryDetailId = categoryDetailId;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public BigDecimal getQuantity() {
		return quantity;
	}
	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}
	public BigDecimal getBuyingPrice() {
		return buyingPrice;
	}
	public void setBuyingPrice(BigDecimal buyingPrice) {
		this.buyingPrice = buyingPrice;
	}
	public BigDecimal getOriginalSellingPrice() {
		return originalSellingPrice;
	}
	public void setOriginalSellingPrice(BigDecimal originalSellingPrice) {
		this.originalSellingPrice = originalSellingPrice;
	}
	
	public String getDetailNote() {
		return detailNote;
	}
	public void setDetailNote(String detailNote) {
		this.detailNote = detailNote;
	}
	public String getDetailDeleteFlg() {
		return detailDeleteFlg;
	}
	public void setDetailDeleteFlg(String detailDeleteFlg) {
		this.detailDeleteFlg = detailDeleteFlg;
	}
	public String getDetailLargeImgPath() {
		return detailLargeImgPath;
	}
	public void setDetailLargeImgPath(String detailLargeImgPath) {
		this.detailLargeImgPath = detailLargeImgPath;
	}
	public String getDetailSmallImgPath() {
		return detailSmallImgPath;
	}
	public void setDetailSmallImgPath(String detailSmallImgPath) {
		this.detailSmallImgPath = detailSmallImgPath;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getdDeleteFlg() {
		return detailDeleteFlg;
	}
	public void setdDeleteFlg(String dDeleteFlg) {
		this.detailDeleteFlg = dDeleteFlg;
	}
	public String getdLImgPath() {
		return detailLargeImgPath;
	}
	public void setdLImgPath(String dLImgPath) {
		this.detailLargeImgPath = dLImgPath;
	}
	public String getdSImgPath() {
		return detailSmallImgPath;
	}
	public void setdSImgPath(String dSImgPath) {
		this.detailSmallImgPath = dSImgPath;
	}
	public BigDecimal getCurrentSellingPrice() {
		return currentSellingPrice;
	}
	public void setCurrentSellingPrice(BigDecimal currentSellingPrice) {
		this.currentSellingPrice = currentSellingPrice;
	}
	public BigDecimal getDiscountPercent() {
		return discountPercent;
	}
	public void setDiscountPercent(BigDecimal discountPercent) {
		this.discountPercent = discountPercent;
	}
	public BigDecimal getPartId() {
		return partId;
	}
	public void setPartId(BigDecimal partId) {
		this.partId = partId;
	}
	public BigDecimal getBrandId() {
		return brandId;
	}
	public void setBrandId(BigDecimal brandId) {
		this.brandId = brandId;
	}
	public BigDecimal getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(BigDecimal categoryId) {
		this.categoryId = categoryId;
	}
	
	
	
}
