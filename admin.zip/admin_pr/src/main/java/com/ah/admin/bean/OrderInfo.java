package com.ah.admin.bean;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class OrderInfo {
	
	private BigDecimal sellOrderId;
	private BigDecimal categoryDetailId;
	private String adminConfirmFlg;
	private BigDecimal sellQuantity;
	private String cancellableFlg;
	private String executionFlg;
	private String orderCompleteFlg;
	private Timestamp orderTimestamp;
	private Timestamp updatedTimestamp;
	private Timestamp executionTimestamp;
	private Timestamp cancellationTimestamp;
	private String lastUpdater;
	private String note;
	private BigDecimal sellAmount;
	private String deliveryId;
	private BigDecimal sellPrice;
	private BigDecimal tradingAmount;
	private BigDecimal customerId;
	private String customerName;
	private String customerPhone;
	private String customerEmail;
	private String customerAddress;
	private String blockFlg;
	private Long year;
	private String make;
	private String model;
	private String brandName;
	private String partName;
	public BigDecimal getSellOrderId() {
		return sellOrderId;
	}
	public void setSellOrderId(BigDecimal sellOrderId) {
		this.sellOrderId = sellOrderId;
	}
	public BigDecimal getCategoryDetailId() {
		return categoryDetailId;
	}
	public void setCategoryDetailId(BigDecimal categoryDetailId) {
		this.categoryDetailId = categoryDetailId;
	}
	public String getAdminConfirmFlg() {
		return adminConfirmFlg;
	}
	public void setAdminConfirmFlg(String adminConfirmFlg) {
		this.adminConfirmFlg = adminConfirmFlg;
	}
	public BigDecimal getSellQuantity() {
		return sellQuantity;
	}
	public void setSellQuantity(BigDecimal sellQuantity) {
		this.sellQuantity = sellQuantity;
	}
	public String getCancellableFlg() {
		return cancellableFlg;
	}
	public void setCancellableFlg(String cancellableFlg) {
		this.cancellableFlg = cancellableFlg;
	}
	public String getExecutionFlg() {
		return executionFlg;
	}
	public void setExecutionFlg(String executionFlg) {
		this.executionFlg = executionFlg;
	}
	public String getOrderCompleteFlg() {
		return orderCompleteFlg;
	}
	public void setOrderCompleteFlg(String orderCompleteFlg) {
		this.orderCompleteFlg = orderCompleteFlg;
	}
	public Timestamp getOrderTimestamp() {
		return orderTimestamp;
	}
	public void setOrderTimestamp(Timestamp orderTimestamp) {
		this.orderTimestamp = orderTimestamp;
	}
	public Timestamp getUpdatedTimestamp() {
		return updatedTimestamp;
	}
	public void setUpdatedTimestamp(Timestamp updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}
	public Timestamp getExecutionTimestamp() {
		return executionTimestamp;
	}
	public void setExecutionTimestamp(Timestamp executionTimestamp) {
		this.executionTimestamp = executionTimestamp;
	}
	public Timestamp getCancellationTimestamp() {
		return cancellationTimestamp;
	}
	public void setCancellationTimestamp(Timestamp cancellationTimestamp) {
		this.cancellationTimestamp = cancellationTimestamp;
	}
	public String getLastUpdater() {
		return lastUpdater;
	}
	public void setLastUpdater(String lastUpdater) {
		this.lastUpdater = lastUpdater;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public BigDecimal getSellAmount() {
		return sellAmount;
	}
	public void setSellAmount(BigDecimal sellAmount) {
		this.sellAmount = sellAmount;
	}
	public String getDeliveryId() {
		return deliveryId;
	}
	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}
	public BigDecimal getSellPrice() {
		return sellPrice;
	}
	public void setSellPrice(BigDecimal sellPrice) {
		this.sellPrice = sellPrice;
	}
	public BigDecimal getTradingAmount() {
		return tradingAmount;
	}
	public void setTradingAmount(BigDecimal tradingAmount) {
		this.tradingAmount = tradingAmount;
	}
	public BigDecimal getCustomerId() {
		return customerId;
	}
	public void setCustomerId(BigDecimal customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerPhone() {
		return customerPhone;
	}
	public void setCustomerPhone(String customerPhone) {
		this.customerPhone = customerPhone;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getBlockFlg() {
		return blockFlg;
	}
	public void setBlockFlg(String blockFlg) {
		this.blockFlg = blockFlg;
	}
	public Long getYear() {
		return year;
	}
	public void setYear(Long year) {
		this.year = year;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getPartName() {
		return partName;
	}
	public void setPartName(String partName) {
		this.partName = partName;
	}
	
	
	
	

}
