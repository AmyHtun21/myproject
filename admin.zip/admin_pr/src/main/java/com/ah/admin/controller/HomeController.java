package com.ah.admin.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.servlet.http.HttpSession;

import org.ocpsoft.rewrite.annotation.Join;

import org.ocpsoft.rewrite.el.ELBeanName;


import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ah.admin.bean.BrandCategoryPart;
import com.ah.admin.bean.Category;
import com.ah.admin.bean.CategoryItem;
import com.ah.admin.bean.Parts;



@Scope(value = "session")

@Component(value = "productController")

@ELBeanName(value = "productController")

@Join(path = "/product", to = "/product-form.jsf")

public class HomeController extends CommonController{
	
	 final String CATEGORY_DETAIL_ALL = "http://localhost:8082/categoryDetailListBySelledQty";
	 
	 final String FIND_BY_CATEGORY="http://localhost:8082/categoryDetailListByCategoryId?";
	 
	 final String CATEGORY_LIST="http://localhost:8082/categoryItem";
	 
	 final String FIND_BY_PART="http://localhost:8082/partMasterList?partId=";
	 
	 final String FIND_BRAND_BY_CATEGORY="http://localhost:8082/categoryPartMasterList?year=";
	 
	 final String HOME="http://localhost:8082/homeList";
	
	private List<Category> categoryList;
	
	private Long year;
	
	private String make;
	
	private String model;
	
	private Category category=new Category();
	
	private String partName;
	
	private BrandCategoryPart homeBrandCategoryPart;
	
	private CategoryItem catItem;
	
	private boolean makeRender;
	
	private boolean modelRender;
	
	private String deliveryId;
	
	private BigDecimal deliveryFees;
	
    public HomeController() {

System.out.println("Controller is calling");
    	
    }

    public String save() {      
         
        return "/product-list.xhtml?faces-redirect=true";

    }
    public String partDetailList(Parts selectedParts) {

      System.out.println("This is selected Part List"+selectedParts.getPartId());
    partName=selectedParts.getPartName();
      RestTemplate restTemplate = new RestTemplate();
      ResponseEntity<BrandCategoryPart> responseEntity = restTemplate.getForEntity(FIND_BY_PART+selectedParts.getPartId(), BrandCategoryPart.class);
      homeBrandCategoryPart=responseEntity.getBody();
      System.out.println(homeBrandCategoryPart.getDeliveryInfoList()+" is delivery info list");
        return "/partdetail-list.xhtml?faces-redirect=true";

    }    
    
    public void searchAllCategory(ActionEvent actionEvent) {
    	System.out.println("Reach in search all");
    	 RestTemplate restTemplate = new RestTemplate();
    	 ResponseEntity<CategoryItem> responseEntity=restTemplate.getForEntity(CATEGORY_LIST, CategoryItem.class);
    	 catItem=responseEntity.getBody();
    	 System.out.println("final is"+catItem.getYear());
    	 }
    	
    public void onYearChange() {
    	System.out.println("Reach in onYearChange"+year);
        if(year !=null && !year.equals("")) {
        	catItem.setMakeData(catItem.getMakeMap().get(year));
        }
        else 
        {
        	catItem.setMakeData(new HashMap<String,String>());
        }
        setMakeRender(true);
        System.out.println("Make value is"+catItem.getMakeData()+isMakeRender());
    }
    
    public void onMakeChange() {
    	System.out.println("Reach in onMakeChange"+make);
        if(make !=null && !make.equals("")) {
        	catItem.setModelData(catItem.getModelMap().get(make));
        }
        else 
        {
        	catItem.setModelData(new HashMap<String,String>());
        }
        modelRender=true;
        System.out.println("Model value is"+catItem.getModelData());
    }
     

	public String refresh() {
		setYear(null);
		setMake(null);
		setModel(null);
		setMakeRender(false);
		setModelRender(false);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<BrandCategoryPart> responseEntity = restTemplate.getForEntity(HOME, BrandCategoryPart.class);
        homeBrandCategoryPart=responseEntity.getBody();
        ResponseEntity<CategoryItem> catResponseEntity=restTemplate.getForEntity(CATEGORY_LIST, CategoryItem.class);
	   	 catItem=catResponseEntity.getBody();


FacesContext fCtx = FacesContext.getCurrentInstance();
HttpSession session = (HttpSession) fCtx.getExternalContext().getSession(false);
String sessionId = session.getId();

System.out.println(sessionId+" is current id.");
        return "/product-form.xhtml";
	}
	
	public void searchCategory() {
		RestTemplate restTemplate = new RestTemplate();
	   	 ResponseEntity<CategoryItem> catResponseEntity=restTemplate.getForEntity(CATEGORY_LIST, CategoryItem.class);
	   	 catItem=catResponseEntity.getBody();
	   	 System.out.println("final is"+catItem.getYear());
	}
	
	
	public String searchByCategory() {
		RestTemplate restTemplate = new RestTemplate();
	   	 ResponseEntity<BrandCategoryPart> catResponseEntity=restTemplate.getForEntity(FIND_BRAND_BY_CATEGORY+year+"&&make="+make+"&&model="+model, BrandCategoryPart.class);
	   	 homeBrandCategoryPart=catResponseEntity.getBody();
	   	 System.out.println("Reach in category"+year+make+model+homeBrandCategoryPart.getPartList());
	   	 System.out.println(FIND_BRAND_BY_CATEGORY+year+"&&make="+make+"&&model="+model);
/*			setYear(null);
			setMake(null);
			setModel(null);
			setMakeRender(false);
			setModelRender(false);*/
	   	 return "/category-parts.xhtml?faces-redirect=true";
	
	}


	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public BrandCategoryPart getHomeBrandCategoryPart() {
		return homeBrandCategoryPart;
	}

	public void setHomeBrandCategoryPart(BrandCategoryPart homeBrandCategoryPart) {
		this.homeBrandCategoryPart = homeBrandCategoryPart;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public CategoryItem getCatItem() {
		return catItem;
	}

	public void setCatItem(CategoryItem catItem) {
		this.catItem = catItem;
	}

	public boolean isMakeRender() {
		return makeRender;
	}

	public void setMakeRender(boolean makeRender) {
		this.makeRender = makeRender;
	}

	public boolean isModelRender() {
		return modelRender;
	}

	public void setModelRender(boolean modelRender) {
		this.modelRender = modelRender;
	}

	public String getDeliveryId() {
		return deliveryId;
	}

	public void setDeliveryId(String deliveryId) {
		this.deliveryId = deliveryId;
	}

	public BigDecimal getDeliveryFees() {
		return deliveryFees;
	}

	public void setDeliveryFees(BigDecimal deliveryFees) {
		this.deliveryFees = deliveryFees;
	}












}