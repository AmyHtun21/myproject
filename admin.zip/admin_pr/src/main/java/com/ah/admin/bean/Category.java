package com.ah.admin.bean;



public class Category {
	
	private Long categoryId;
	private Long year;
	private String make;
	private String model;
	private String categoryDeleteFlg;
	
	public Category() {}
	public Category(Long categoryId,Long year,String make,String model,String cDeleteFlg) {
		this.categoryId=categoryId;
		this.year=year;
		this.make=make;
		this.model=model;
		this.categoryDeleteFlg=cDeleteFlg;
	}
	
	public Long getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}
	public Long getYear() {
		return year;
	}
	public void setYear(Long year) {
		this.year = year;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getCategoryDeleteFlg() {
		return categoryDeleteFlg;
	}
	public void setCategoryDeleteFlg(String categoryDeleteFlg) {
		this.categoryDeleteFlg = categoryDeleteFlg;
	}

	public String toString() {
		return year+make+model;
	}

}
