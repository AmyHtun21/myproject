function showGrid(var gridName){
	
	document.getElementById(gridName).style.display='';
}